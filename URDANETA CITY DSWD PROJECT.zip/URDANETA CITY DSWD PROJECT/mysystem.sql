-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 03, 2026 at 12:44 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mysystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `aids`
--

CREATE TABLE `aids` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `aid_type` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Pending',
  `date_received` date DEFAULT NULL,
  `barangay` varchar(255) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `aid_assistances`
--

CREATE TABLE `aid_assistances` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `minor_id` bigint(20) UNSIGNED NOT NULL,
  `date_given` date NOT NULL,
  `receiver_name` varchar(255) DEFAULT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  `assistance_type` varchar(255) NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `aid_assistances`
--

INSERT INTO `aid_assistances` (`id`, `minor_id`, `date_given`, `receiver_name`, `quantity`, `assistance_type`, `notes`, `created_at`, `updated_at`) VALUES
(7, 6, '2025-07-30', 'sdfs', '3', 'dsfsd', 'sdfs', '2025-07-29 16:50:54', '2025-07-29 16:50:54'),
(8, 2, '2025-07-30', 'Banjo O . Bautista', '1', 'Food Pack', 'asdad', '2025-07-29 18:36:39', '2025-07-29 18:36:39'),
(10, 7, '2025-11-22', 'nel', '1', 'Food Pack', 'for bagyo', '2025-11-22 10:23:36', '2025-11-22 10:23:36');

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `imageUrl` varchar(255) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `date` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `title`, `description`, `imageUrl`, `due_date`, `date`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'banjo', 'banjo has announce', 'announcement_images/Unl0tuG8kQI005QDZLSOQOs5CHfq86SjpNUD7jXe.png', '2025-08-01', 'Jul 06, 2025', '2025-07-06 09:05:39', '2025-07-06 09:05:39', NULL),
(2, 'fadsf', 'asass', 'announcement_images/1Ia1PtcmTcwtOZC3UpzdFy8T9oJX9lovgjaucVMW.png', '2025-08-20', 'Jul 13, 2025', '2025-07-12 19:49:03', '2025-07-12 19:49:03', NULL),
(7, 'afasf', 'asfaf', 'announcement_images/eDmqSO6f1wr8HEjELe6AoLO9oRlimhVoBtZZxwv0.png', '2025-08-15', '2025-07-13', '2025-07-13 06:57:38', '2025-07-13 06:57:38', NULL),
(8, 'afaf', 'fafaf', 'announcement_images/KFJAKz7cZ0YQ9hu1k8CBF2HHNknMqFUntnIJOTqH.png', '2025-08-15', '2025-07-13', '2025-07-13 06:57:50', '2025-07-13 06:57:50', NULL),
(9, 'this', 'yes', 'announcement_images/PH9PFuBPNo48AD1gDauDMvCnrJRh7xWTzox7rddz.png', '2025-08-19', '2025-07-28', '2025-07-27 08:30:51', '2025-07-27 08:30:51', NULL),
(10, 'updated', 'updated', 'announcement_images/uj7IIVETe4h4rPQOQAUwp2gAS2tIyx5fP43zBa55.png', '2025-08-08', '2025-07-27', '2025-07-27 12:47:05', '2025-07-27 12:47:05', NULL),
(11, 'test 1', 'test 1', 'announcement_images/LaVfRLZzbOaddd3RexYpNA9iCrJQGHsyfdlAJQMM.png', '2025-08-28', 'Aug 07, 2025', '2025-08-07 06:07:16', '2025-08-07 06:07:16', NULL),
(12, 'test 2', 'test 2', 'announcement_images/eKh7psZ5h7yujYsWziCdKCoHwS7QOD2IjBhEbKXJ.png', '2025-08-09', 'Aug 07, 2025', '2025-08-07 06:08:34', '2025-08-07 06:08:34', NULL),
(13, 'test 3', 'test 3', 'announcement_images/mrFx6cYiXPJM1V4thsZocY0BCAZCB0VzAHeGibti.png', '2025-08-08', 'Aug 07, 2025', '2025-08-07 06:36:03', '2025-08-07 06:36:03', NULL),
(14, 'test 4', 'test 4', 'announcement_images/nlfA1dc7cT15vH1quNwCGaTUsQ98QmON7OLWAyRb.png', '2025-08-08', 'Aug 07, 2025', '2025-08-07 14:09:37', '2025-08-07 14:09:37', NULL),
(15, 'PWD PROGRAMS', 'COME AND HAVE A FREE CONSULTATION ON YOU HEALTH', 'announcement_images/Kaajebbl4f9wcgal1YjVeDy7591fAmyeYJfeZMrM.jpg', '2025-11-30', 'Nov 22, 2025', '2025-11-21 18:19:45', '2025-11-21 18:19:45', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `archived_records`
--

CREATE TABLE `archived_records` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `brgy` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `sex` varchar(255) NOT NULL,
  `daycare_center` varchar(255) DEFAULT NULL,
  `original_section` varchar(255) NOT NULL,
  `original_id` bigint(20) UNSIGNED NOT NULL,
  `minor_id` bigint(20) UNSIGNED DEFAULT NULL,
  `record_type` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `archived_records`
--

INSERT INTO `archived_records` (`id`, `name`, `brgy`, `age`, `sex`, `daycare_center`, `original_section`, `original_id`, `minor_id`, `record_type`, `created_at`, `updated_at`) VALUES
(15, 'NOLY OLIVO BAUTISTA', 'bantog', 5, 'female', 'Bactad East CDC', 'children-records', 4, 4, 'App\\Models\\Minor', '2025-08-17 06:55:05', '2025-08-17 06:55:05'),
(16, 'john alexis r rosendo', 'san_jose', 49, 'male', NULL, 'children-records', 15, 15, 'App\\Models\\Minor', '2025-09-16 14:02:34', '2025-09-16 14:02:34'),
(18, 'dsadasdasd adasdasdasd sdasdas', 'san_miguel', 7, 'female', NULL, 'daycare-records', 5, 5, 'App\\Models\\Minor', '2025-11-16 11:11:53', '2025-11-16 11:11:53'),
(22, 'aida olivo bautista', 'GUISET NORTE', 4, 'female', NULL, 'children-records', 2, 2, 'App\\Models\\Minor', '2025-11-24 02:37:24', '2025-11-24 02:37:24');

-- --------------------------------------------------------

--
-- Stand-in structure for view `archived_with_minors`
-- (See below for the actual view)
--
CREATE TABLE `archived_with_minors` (
`id` bigint(20) unsigned
,`name` varchar(255)
,`brgy` varchar(255)
,`age` int(11)
,`sex` varchar(255)
,`daycare_center` varchar(255)
,`original_section` varchar(255)
,`original_id` bigint(20) unsigned
,`minor_id` bigint(20) unsigned
,`record_type` varchar(255)
,`created_at` timestamp
,`updated_at` timestamp
,`minor_last_name` varchar(255)
,`minor_first_name` varchar(255)
,`minor_middle_name` varchar(255)
,`minor_barangay` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `audits`
--

CREATE TABLE `audits` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_type` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `event` varchar(255) NOT NULL,
  `auditable_type` varchar(255) NOT NULL,
  `auditable_id` bigint(20) UNSIGNED NOT NULL,
  `old_values` text DEFAULT NULL,
  `new_values` text DEFAULT NULL,
  `url` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(1023) DEFAULT NULL,
  `tags` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `audits`
--

INSERT INTO `audits` (`id`, `user_type`, `user_id`, `event`, `auditable_type`, `auditable_id`, `old_values`, `new_values`, `url`, `ip_address`, `user_agent`, `tags`, `created_at`, `updated_at`) VALUES
(1, NULL, NULL, 'updated', 'App\\Models\\Minor', 1, '{\"minor_middle_name\":\"castro\",\"minor_age\":273,\"minor_sex\":\"Female\",\"minor_educational_attainment\":\"none\",\"pwd_other_type_of_disability\":null,\"case_category\":null,\"assistive_devices_needed\":null}', '{\"minor_middle_name\":\"test\",\"minor_age\":273.99919519824823,\"minor_sex\":\"male\",\"minor_educational_attainment\":null,\"pwd_other_type_of_disability\":null,\"case_category\":null,\"assistive_devices_needed\":null}', 'http://127.0.0.1:8000/admin/children-records/1', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL, '2025-08-07 15:24:04', '2025-08-07 15:24:04'),
(2, 'App\\Models\\User', 1, 'updated', 'App\\Models\\Minor', 1, '{\"minor_last_name\":\"bautista\",\"minor_age\":273,\"minor_sex\":\"Female\"}', '{\"minor_last_name\":\"test\",\"minor_age\":273.99925186673124,\"minor_sex\":\"male\"}', 'http://127.0.0.1:8000/staff/children-records/1', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL, '2025-08-07 15:26:36', '2025-08-07 15:26:36'),
(3, NULL, NULL, 'updated', 'App\\Models\\Minor', 23, '{\"approval_status\":\"pending\"}', '{\"approval_status\":\"approved\"}', 'http://127.0.0.1:8000/admin/approvals/23/approve', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL, '2025-08-10 07:18:41', '2025-08-10 07:18:41'),
(4, NULL, NULL, 'updated', 'App\\Models\\Minor', 22, '{\"approval_status\":\"pending\"}', '{\"approval_status\":\"approved\"}', 'http://127.0.0.1:8000/admin/approvals/22/approve', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL, '2025-08-10 07:18:43', '2025-08-10 07:18:43'),
(5, NULL, NULL, 'updated', 'App\\Models\\Minor', 21, '{\"approval_status\":\"pending\"}', '{\"approval_status\":\"approved\"}', 'http://127.0.0.1:8000/admin/approvals/21/approve', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL, '2025-08-10 07:18:43', '2025-08-10 07:18:43'),
(6, NULL, NULL, 'updated', 'App\\Models\\Minor', 20, '{\"approval_status\":\"pending\"}', '{\"approval_status\":\"approved\"}', 'http://127.0.0.1:8000/admin/approvals/20/approve', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL, '2025-08-10 07:18:44', '2025-08-10 07:18:44'),
(7, NULL, NULL, 'updated', 'App\\Models\\Minor', 19, '{\"approval_status\":\"pending\"}', '{\"approval_status\":\"approved\"}', 'http://127.0.0.1:8000/admin/approvals/19/approve', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL, '2025-08-10 07:18:44', '2025-08-10 07:18:44'),
(8, NULL, NULL, 'updated', 'App\\Models\\Minor', 18, '{\"approval_status\":\"pending\"}', '{\"approval_status\":\"approved\"}', 'http://127.0.0.1:8000/admin/approvals/18/approve', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL, '2025-08-10 07:18:45', '2025-08-10 07:18:45'),
(9, NULL, NULL, 'updated', 'App\\Models\\Minor', 17, '{\"approval_status\":\"pending\"}', '{\"approval_status\":\"approved\"}', 'http://127.0.0.1:8000/admin/approvals/17/approve', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL, '2025-08-10 07:18:45', '2025-08-10 07:18:45'),
(10, NULL, NULL, 'updated', 'App\\Models\\Minor', 16, '{\"approval_status\":\"pending\"}', '{\"approval_status\":\"approved\"}', 'http://127.0.0.1:8000/admin/approvals/16/approve', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL, '2025-08-10 07:18:46', '2025-08-10 07:18:46'),
(11, NULL, NULL, 'updated', 'App\\Models\\Minor', 15, '{\"approval_status\":\"pending\"}', '{\"approval_status\":\"approved\"}', 'http://127.0.0.1:8000/admin/approvals/15/approve', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL, '2025-08-10 07:18:46', '2025-08-10 07:18:46'),
(12, NULL, NULL, 'updated', 'App\\Models\\Minor', 13, '{\"approval_status\":\"pending\"}', '{\"approval_status\":\"approved\"}', 'http://127.0.0.1:8000/admin/approvals/13/approve', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL, '2025-08-10 07:18:47', '2025-08-10 07:18:47'),
(13, NULL, NULL, 'updated', 'App\\Models\\Minor', 12, '{\"approval_status\":\"pending\"}', '{\"approval_status\":\"approved\"}', 'http://127.0.0.1:8000/admin/approvals/12/approve', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL, '2025-08-10 07:18:48', '2025-08-10 07:18:48'),
(14, NULL, NULL, 'updated', 'App\\Models\\Minor', 11, '{\"approval_status\":\"pending\"}', '{\"approval_status\":\"approved\"}', 'http://127.0.0.1:8000/admin/approvals/11/approve', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL, '2025-08-10 07:18:48', '2025-08-10 07:18:48'),
(15, NULL, NULL, 'updated', 'App\\Models\\Minor', 7, '{\"approval_status\":\"pending\"}', '{\"approval_status\":\"approved\"}', 'http://127.0.0.1:8000/admin/approvals/7/approve', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL, '2025-08-10 07:18:49', '2025-08-10 07:18:49'),
(16, NULL, NULL, 'updated', 'App\\Models\\Minor', 5, '{\"approval_status\":\"pending\"}', '{\"approval_status\":\"approved\"}', 'http://127.0.0.1:8000/admin/approvals/5/approve', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL, '2025-08-10 07:18:49', '2025-08-10 07:18:49'),
(17, NULL, NULL, 'updated', 'App\\Models\\Minor', 4, '{\"approval_status\":\"pending\"}', '{\"approval_status\":\"approved\"}', 'http://127.0.0.1:8000/admin/approvals/4/approve', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL, '2025-08-10 07:18:50', '2025-08-10 07:18:50'),
(18, NULL, NULL, 'updated', 'App\\Models\\Minor', 2, '{\"approval_status\":\"pending\"}', '{\"approval_status\":\"approved\"}', 'http://127.0.0.1:8000/admin/approvals/2/approve', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL, '2025-08-10 07:18:50', '2025-08-10 07:18:50'),
(19, NULL, NULL, 'created', 'App\\Models\\Minor', 24, '[]', '{\"application_type\":\"new_applicant\",\"date_applied\":\"2025-08-10 00:00:00\",\"minor_last_name\":\"test1\",\"minor_first_name\":\"test1\",\"minor_middle_name\":\"test1\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2022-08-10 00:00:00\",\"minor_age\":\"36\",\"minor_sex\":\"male\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"33\",\"minor_barangay\":\"san_juan\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":\"5465\",\"guardian_mobile_no\":\"6564356346\",\"guardian_email_address\":\"test1@gmail.com\",\"minor_educational_attainment\":\"none\",\"father_last_name\":\"test1\",\"father_first_name\":\"test1\",\"father_middle_name\":\"test1\",\"mother_last_name\":\"test1\",\"mother_first_name\":\"test1\",\"mother_middle_name\":\"test1\",\"guardian_last_name\":\"test1\",\"guardian_first_name\":\"test1\",\"guardian_middle_name\":\"test1\",\"is_pwd_minor\":false,\"is_daycare_student\":false,\"accomplished_by\":\"applicant\",\"representative_name\":null,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"name_of_reporting_unit\":null,\"control_no\":null,\"doctor_certified_by\":null,\"license_no_physician\":null,\"pwd_type_of_disability\":null,\"pwd_cause_of_disability\":null,\"id\":24}', 'http://127.0.0.1:8000/submit-minor-form', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL, '2025-08-10 07:55:02', '2025-08-10 07:55:02'),
(20, NULL, NULL, 'updated', 'App\\Models\\Minor', 1, '{\"approval_status\":\"pending\"}', '{\"approval_status\":\"approved\"}', 'http://127.0.0.1:8000/admin/approvals/1/approve', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL, '2025-08-10 07:58:26', '2025-08-10 07:58:26'),
(21, NULL, NULL, 'updated', 'App\\Models\\Minor', 6, '{\"approval_status\":\"pending\"}', '{\"approval_status\":\"approved\"}', 'http://127.0.0.1:8000/admin/approvals/6/approve', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL, '2025-08-10 07:58:31', '2025-08-10 07:58:31'),
(22, NULL, NULL, 'updated', 'App\\Models\\Minor', 14, '{\"approval_status\":\"pending\"}', '{\"approval_status\":\"approved\"}', 'http://127.0.0.1:8000/admin/approvals/14/approve', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL, '2025-08-10 07:58:33', '2025-08-10 07:58:33'),
(23, NULL, NULL, 'updated', 'App\\Models\\Minor', 24, '{\"approval_status\":\"pending\"}', '{\"approval_status\":\"approved\"}', 'http://127.0.0.1:8000/admin/approvals/24/approve', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL, '2025-08-10 07:58:35', '2025-08-10 07:58:35'),
(24, NULL, NULL, 'created', 'App\\Models\\Minor', 25, '[]', '{\"application_type\":\"new_applicant\",\"date_applied\":\"2025-08-11 00:00:00\",\"minor_last_name\":\"test15\",\"minor_first_name\":\"test15\",\"minor_middle_name\":\"test15\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2022-08-11 00:00:00\",\"minor_age\":36,\"minor_sex\":\"male\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"77\",\"minor_barangay\":\"san_jose\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":\"09876\",\"guardian_mobile_no\":\"34653654765\",\"guardian_email_address\":\"test15@gmail.com\",\"minor_educational_attainment\":\"none\",\"minor_other_educational_attainment\":null,\"father_last_name\":\"test15\",\"father_first_name\":\"test15test15\",\"father_middle_name\":\"test15\",\"mother_last_name\":\"test15\",\"mother_first_name\":\"test15\",\"mother_middle_name\":\"test15\",\"guardian_last_name\":\"test15\",\"guardian_first_name\":\"test15\",\"guardian_middle_name\":\"test15\",\"is_pwd_minor\":true,\"pwd_type_of_disability\":\"[]\",\"pwd_cause_of_disability\":\"[]\",\"pwd_other_disability_cause\":null,\"is_daycare_student\":true,\"daycare_actual_weight_date\":null,\"daycare_weight_kg\":null,\"daycare_height_cm\":null,\"daycare_weight_for_age\":null,\"daycare_height_for_age\":null,\"daycare_weight_for_height\":null,\"accomplished_by\":\"applicant\",\"representative_name\":null,\"license_no\":null,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"name_of_reporting_unit\":null,\"control_no\":null,\"doctor_certified_by\":null,\"license_no_physician\":null,\"id\":25}', 'http://127.0.0.1:8000/admin/approvals/1/approve', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL, '2025-08-10 19:22:58', '2025-08-10 19:22:58'),
(25, 'App\\Models\\User', 7, 'updated', 'App\\Models\\Minor', 1, '{\"minor_last_name\":\"test\",\"minor_age\":274,\"minor_educational_attainment\":\"none\",\"pwd_other_type_of_disability\":null,\"case_category\":null,\"assistive_devices_needed\":null}', '{\"minor_last_name\":\"bautista\",\"minor_age\":274.14991534440674,\"minor_educational_attainment\":null,\"pwd_other_type_of_disability\":null,\"case_category\":null,\"assistive_devices_needed\":null}', 'http://127.0.0.1:8000/admin/children-records/1', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL, '2025-08-12 07:32:13', '2025-08-12 07:32:13'),
(26, NULL, NULL, 'updated', 'App\\Models\\Minor', 25, '{\"is_archived\":0}', '{\"is_archived\":true}', 'http://127.0.0.1:8000/teacher/daycare-records/25/archive', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36', NULL, '2025-08-14 19:13:27', '2025-08-14 19:13:27'),
(27, NULL, NULL, 'created', 'App\\Models\\Task', 5, '[]', '{\"task_title\":\"This is new\",\"task_description\":\"Testing if its work\",\"date_created\":\"2025-08-15 00:00:00\",\"due_date\":\"2025-08-20 00:00:00\",\"status\":\"active\",\"id\":5}', 'http://127.0.0.1:8000/admin/tasks', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36', NULL, '2025-08-15 08:00:00', '2025-08-15 08:00:00'),
(28, NULL, NULL, 'updated', 'App\\Models\\Minor', 23, '{\"is_archived\":0}', '{\"is_archived\":true}', 'http://127.0.0.1:8000/teacher/daycare-records/archive/23', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36', NULL, '2025-08-17 06:43:35', '2025-08-17 06:43:35'),
(29, NULL, NULL, 'deleted', 'App\\Models\\Minor', 4, '{\"id\":4,\"application_type\":\"new_applicant\",\"date_applied\":\"2024-11-07\",\"minor_last_name\":\"BAUTISTA\",\"minor_first_name\":\"NOLY\",\"minor_middle_name\":\"OLIVO\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2025-01-10\",\"minor_age\":5,\"minor_sex\":\"female\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"Bani Pangasinan\",\"minor_barangay\":\"bantog\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":null,\"guardian_mobile_no\":\"+639506440263\",\"guardian_email_address\":\"bautista.noly16@gmail.com\",\"minor_educational_attainment\":\"none\",\"minor_other_educational_attainment\":null,\"father_last_name\":\"BAUTISTA\",\"father_first_name\":\"NOLY\",\"father_middle_name\":\"CASTRO\",\"mother_last_name\":\"BAUTISTA\",\"mother_first_name\":\"NOLY\",\"mother_middle_name\":\"OLIVO\",\"guardian_last_name\":\"BAUTISTA\",\"guardian_first_name\":\"NOLY\",\"guardian_middle_name\":\"OLIVO\",\"is_pwd_minor\":1,\"pwd_registration_status\":\"first_time\",\"pwd_number\":null,\"pwd_type_of_disability\":\"[\\\"intellectual_disability\\\"]\",\"pwd_cause_of_disability\":\"[\\\"acquired\\\"]\",\"pwd_other_disability_cause\":null,\"is_daycare_student\":1,\"is_archived\":0,\"daycare_actual_weight_date\":\"2025-07-09\",\"daycare_weight_kg\":\"34.00\",\"daycare_height_cm\":\"34.00\",\"daycare_weight_for_age\":\"N\\/A\",\"daycare_height_for_age\":\"N\\/A\",\"daycare_weight_for_height\":\"N\\/A\",\"accomplished_by\":\"applicant\",\"representative_name\":null,\"license_no\":null,\"processing_officer\":\"VICTOR MAGTANGGOL\",\"approving_officer\":\"JULIUS REPOLLO\",\"encoder\":\"asdasd\",\"name_of_reporting_unit\":\"asdasdad\",\"control_no\":\"adasda\",\"doctor_certified_by\":\"dfdgffhd\",\"license_no_physician\":null}', '[]', 'http://127.0.0.1:8000/admin/children-records/4/archive', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36', NULL, '2025-08-17 06:54:45', '2025-08-17 06:54:45'),
(30, NULL, NULL, 'restored', 'App\\Models\\Minor', 4, '[]', '{\"id\":4,\"application_type\":\"new_applicant\",\"date_applied\":\"2024-11-07\",\"minor_last_name\":\"BAUTISTA\",\"minor_first_name\":\"NOLY\",\"minor_middle_name\":\"OLIVO\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2025-01-10\",\"minor_age\":5,\"minor_sex\":\"female\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"Bani Pangasinan\",\"minor_barangay\":\"bantog\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":null,\"guardian_mobile_no\":\"+639506440263\",\"guardian_email_address\":\"bautista.noly16@gmail.com\",\"minor_educational_attainment\":\"none\",\"minor_other_educational_attainment\":null,\"father_last_name\":\"BAUTISTA\",\"father_first_name\":\"NOLY\",\"father_middle_name\":\"CASTRO\",\"mother_last_name\":\"BAUTISTA\",\"mother_first_name\":\"NOLY\",\"mother_middle_name\":\"OLIVO\",\"guardian_last_name\":\"BAUTISTA\",\"guardian_first_name\":\"NOLY\",\"guardian_middle_name\":\"OLIVO\",\"is_pwd_minor\":1,\"pwd_registration_status\":\"first_time\",\"pwd_number\":null,\"pwd_type_of_disability\":\"[\\\"intellectual_disability\\\"]\",\"pwd_cause_of_disability\":\"[\\\"acquired\\\"]\",\"pwd_other_disability_cause\":null,\"is_daycare_student\":1,\"is_archived\":0,\"daycare_actual_weight_date\":\"2025-07-09\",\"daycare_weight_kg\":\"34.00\",\"daycare_height_cm\":\"34.00\",\"daycare_weight_for_age\":\"N\\/A\",\"daycare_height_for_age\":\"N\\/A\",\"daycare_weight_for_height\":\"N\\/A\",\"accomplished_by\":\"applicant\",\"representative_name\":null,\"license_no\":null,\"processing_officer\":\"VICTOR MAGTANGGOL\",\"approving_officer\":\"JULIUS REPOLLO\",\"encoder\":\"asdasd\",\"name_of_reporting_unit\":\"asdasdad\",\"control_no\":\"adasda\",\"doctor_certified_by\":\"dfdgffhd\",\"license_no_physician\":null}', 'http://127.0.0.1:8000/admin/archived-records/14/restore', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36', NULL, '2025-08-17 06:54:54', '2025-08-17 06:54:54'),
(31, NULL, NULL, 'deleted', 'App\\Models\\Minor', 4, '{\"id\":4,\"application_type\":\"new_applicant\",\"date_applied\":\"2024-11-07\",\"minor_last_name\":\"BAUTISTA\",\"minor_first_name\":\"NOLY\",\"minor_middle_name\":\"OLIVO\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2025-01-10\",\"minor_age\":5,\"minor_sex\":\"female\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"Bani Pangasinan\",\"minor_barangay\":\"bantog\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":null,\"guardian_mobile_no\":\"+639506440263\",\"guardian_email_address\":\"bautista.noly16@gmail.com\",\"minor_educational_attainment\":\"none\",\"minor_other_educational_attainment\":null,\"father_last_name\":\"BAUTISTA\",\"father_first_name\":\"NOLY\",\"father_middle_name\":\"CASTRO\",\"mother_last_name\":\"BAUTISTA\",\"mother_first_name\":\"NOLY\",\"mother_middle_name\":\"OLIVO\",\"guardian_last_name\":\"BAUTISTA\",\"guardian_first_name\":\"NOLY\",\"guardian_middle_name\":\"OLIVO\",\"is_pwd_minor\":1,\"pwd_registration_status\":\"first_time\",\"pwd_number\":null,\"pwd_type_of_disability\":\"[\\\"intellectual_disability\\\"]\",\"pwd_cause_of_disability\":\"[\\\"acquired\\\"]\",\"pwd_other_disability_cause\":null,\"is_daycare_student\":1,\"is_archived\":0,\"daycare_actual_weight_date\":\"2025-07-09\",\"daycare_weight_kg\":\"34.00\",\"daycare_height_cm\":\"34.00\",\"daycare_weight_for_age\":\"N\\/A\",\"daycare_height_for_age\":\"N\\/A\",\"daycare_weight_for_height\":\"N\\/A\",\"accomplished_by\":\"applicant\",\"representative_name\":null,\"license_no\":null,\"processing_officer\":\"VICTOR MAGTANGGOL\",\"approving_officer\":\"JULIUS REPOLLO\",\"encoder\":\"asdasd\",\"name_of_reporting_unit\":\"asdasdad\",\"control_no\":\"adasda\",\"doctor_certified_by\":\"dfdgffhd\",\"license_no_physician\":null}', '[]', 'http://127.0.0.1:8000/admin/children-records/4/archive', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36', NULL, '2025-08-17 06:55:05', '2025-08-17 06:55:05'),
(32, NULL, NULL, 'updated', 'App\\Models\\Minor', 13, '{\"is_archived\":0}', '{\"is_archived\":true}', 'http://127.0.0.1:8000/teacher/daycare-record/13/archive', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36', NULL, '2025-08-17 07:10:22', '2025-08-17 07:10:22'),
(33, NULL, NULL, 'created', 'App\\Models\\Minor', 26, '[]', '{\"application_type\":\"new_applicant\",\"date_applied\":\"2025-09-16 00:00:00\",\"minor_last_name\":\"sison\",\"minor_first_name\":\"prince\",\"minor_middle_name\":\"sison\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2022-09-16 00:00:00\",\"minor_age\":\"36\",\"minor_sex\":\"female\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"33 sampaloc\",\"minor_barangay\":\"bantog\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":\"N\\/A\",\"guardian_mobile_no\":\"095045634876\",\"guardian_email_address\":\"sison@gmail.com\",\"minor_educational_attainment\":\"kindergarten\",\"father_last_name\":\"sison\",\"father_first_name\":\"sison\",\"father_middle_name\":\"sison\",\"mother_last_name\":\"sison\",\"mother_first_name\":\"sison\",\"mother_middle_name\":\"sison\",\"guardian_last_name\":\"sison\",\"guardian_first_name\":\"sison\",\"guardian_middle_name\":\"sison\",\"is_pwd_minor\":false,\"is_daycare_student\":false,\"accomplished_by\":\"applicant\",\"representative_name\":null,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"name_of_reporting_unit\":null,\"control_no\":null,\"doctor_certified_by\":null,\"license_no_physician\":null,\"pwd_type_of_disability\":null,\"pwd_cause_of_disability\":null,\"id\":26}', 'http://127.0.0.1:8000/submit-minor-form', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36', NULL, '2025-09-16 05:40:59', '2025-09-16 05:40:59'),
(34, NULL, NULL, 'deleted', 'App\\Models\\Minor', 15, '{\"id\":15,\"application_type\":\"new_applicant\",\"date_applied\":\"2025-05-07\",\"minor_last_name\":\"rosendo\",\"minor_first_name\":\"john alexis\",\"minor_middle_name\":\"r\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2021-06-04\",\"minor_age\":49,\"minor_sex\":\"male\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"zone 2\",\"minor_barangay\":\"san_jose\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":\"02838363763\",\"guardian_mobile_no\":\"09167389276\",\"guardian_email_address\":\"jocelyn@gmail.com\",\"minor_educational_attainment\":\"kindergarten\",\"minor_other_educational_attainment\":null,\"father_last_name\":\"rosendo\",\"father_first_name\":\"jose\",\"father_middle_name\":\"m\",\"mother_last_name\":\"rosendo\",\"mother_first_name\":\"jocelyn\",\"mother_middle_name\":\"u.\",\"guardian_last_name\":\"untalan\",\"guardian_first_name\":\"jocelyn\",\"guardian_middle_name\":\"u.\",\"is_pwd_minor\":0,\"pwd_registration_status\":null,\"pwd_number\":null,\"pwd_type_of_disability\":null,\"pwd_cause_of_disability\":null,\"pwd_other_disability_cause\":null,\"is_daycare_student\":1,\"is_archived\":0,\"daycare_actual_weight_date\":\"2025-07-23\",\"daycare_weight_kg\":\"15.00\",\"daycare_height_cm\":\"37.50\",\"daycare_weight_for_age\":\"Normal Weight\",\"daycare_height_for_age\":\"Severely Stunted\",\"daycare_weight_for_height\":\"Severely Obese\",\"accomplished_by\":\"guardian\",\"representative_name\":null,\"license_no\":null,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"name_of_reporting_unit\":null,\"control_no\":null,\"doctor_certified_by\":null,\"license_no_physician\":null}', '[]', 'http://127.0.0.1:8000/admin/children-records/15/archive', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36', NULL, '2025-09-16 14:02:34', '2025-09-16 14:02:34'),
(35, 'App\\Models\\User', 7, 'created', 'App\\Models\\Minor', 27, '[]', '{\"application_type\":\"new_applicant\",\"date_applied\":\"2025-10-05 00:00:00\",\"minor_last_name\":\"bautista\",\"minor_first_name\":\"nap\",\"minor_middle_name\":\"lap\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2021-10-05 00:00:00\",\"minor_age\":\"48\",\"minor_sex\":\"male\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"sampaloc\",\"minor_barangay\":\"san_vicente\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":null,\"guardian_mobile_no\":\"09506440269\",\"guardian_email_address\":\"kill@gmail.com\",\"minor_educational_attainment\":\"kindergarten\",\"father_last_name\":\"BAUTISTA\",\"father_first_name\":\"NOLY\",\"father_middle_name\":\"CASTRO\",\"mother_last_name\":\"BAUTISTA\",\"mother_first_name\":\"NOLY\",\"mother_middle_name\":\"CASTRO\",\"guardian_last_name\":\"BAUTISTA\",\"guardian_first_name\":\"NOLY\",\"guardian_middle_name\":\"CASTRO\",\"is_pwd_minor\":false,\"is_daycare_student\":false,\"accomplished_by\":\"applicant\",\"representative_name\":null,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"name_of_reporting_unit\":null,\"control_no\":null,\"doctor_certified_by\":null,\"license_no_physician\":null,\"pwd_type_of_disability\":null,\"pwd_cause_of_disability\":null,\"id\":27}', 'http://127.0.0.1:8000/submit-minor-form', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36', NULL, '2025-10-05 15:14:12', '2025-10-05 15:14:12'),
(36, 'App\\Models\\User', 1, 'updated', 'App\\Models\\Minor', 27, '{\"minor_first_name\":\"nap\",\"minor_age\":48}', '{\"minor_first_name\":\"napoleon\",\"minor_age\":4.024499129524734}', 'http://127.0.0.1:8000/staff/children-records/27', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36', NULL, '2025-10-13 14:36:44', '2025-10-13 14:36:44'),
(37, 'App\\Models\\User', 1, 'updated', 'App\\Models\\Minor', 27, '{\"minor_age\":4}', '{\"minor_age\":4.024499512878901}', 'http://127.0.0.1:8000/staff/children-records/27', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36', NULL, '2025-10-13 14:36:56', '2025-10-13 14:36:56'),
(38, 'App\\Models\\User', 7, 'created', 'App\\Models\\Minor', 28, '[]', '{\"application_type\":\"new_applicant\",\"date_applied\":\"2025-10-14 00:00:00\",\"minor_last_name\":\"bautista\",\"minor_first_name\":\"lord\",\"minor_middle_name\":\"lapidez\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2021-10-14 00:00:00\",\"minor_age\":\"48\",\"minor_sex\":\"male\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"45 sampaloc\",\"minor_barangay\":\"bantog\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":\"N\\/A\",\"guardian_mobile_no\":\"09509505902\",\"guardian_email_address\":\"lord@gmail.com\",\"minor_educational_attainment\":\"kindergarten\",\"father_last_name\":\"bautista\",\"father_first_name\":\"nap\",\"father_middle_name\":\"castro\",\"mother_last_name\":\"bautista\",\"mother_first_name\":\"benje\",\"mother_middle_name\":\"lapidez\",\"guardian_last_name\":\"bautista\",\"guardian_first_name\":\"nap\",\"guardian_middle_name\":\"castro\",\"is_pwd_minor\":false,\"is_daycare_student\":false,\"accomplished_by\":\"applicant\",\"representative_name\":null,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"name_of_reporting_unit\":null,\"control_no\":null,\"doctor_certified_by\":null,\"license_no_physician\":null,\"pwd_type_of_disability\":null,\"pwd_cause_of_disability\":null,\"id\":28}', 'http://127.0.0.1:8000/submit-minor-form', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36', NULL, '2025-10-14 13:51:54', '2025-10-14 13:51:54'),
(39, 'App\\Models\\User', 7, 'created', 'App\\Models\\Minor', 29, '[]', '{\"application_type\":\"new_applicant\",\"date_applied\":\"2025-10-16 00:00:00\",\"minor_last_name\":\"bautista\",\"minor_first_name\":\"Eleiza Mae\",\"minor_middle_name\":\"falcasantos\",\"minor_suffix\":\"N\\/A\",\"minor_date_of_birth\":\"2022-10-16 00:00:00\",\"minor_age\":\"36\",\"minor_sex\":\"male\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"12 mago\",\"minor_barangay\":\"bantog\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":\"N\\/A\",\"guardian_mobile_no\":\"09506440263\",\"guardian_email_address\":\"bautista.noly16@gmail.com\",\"minor_educational_attainment\":\"kindergarten\",\"father_last_name\":\"BAUTISTA\",\"father_first_name\":\"NOLY\",\"father_middle_name\":\"CASTRO\",\"mother_last_name\":\"BAUTISTA\",\"mother_first_name\":\"NOLY\",\"mother_middle_name\":\"OLIVO\",\"guardian_last_name\":\"BAUTISTA\",\"guardian_first_name\":\"NOLY\",\"guardian_middle_name\":\"OLIVO\",\"is_pwd_minor\":false,\"is_daycare_student\":false,\"accomplished_by\":\"applicant\",\"representative_name\":null,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"name_of_reporting_unit\":null,\"control_no\":null,\"doctor_certified_by\":null,\"license_no_physician\":null,\"pwd_type_of_disability\":null,\"pwd_cause_of_disability\":null,\"id\":29}', 'http://127.0.0.1:8000/submit-minor-form', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36', NULL, '2025-10-16 13:45:58', '2025-10-16 13:45:58'),
(40, 'App\\Models\\User', 8, 'created', 'App\\Models\\Minor', 30, '[]', '{\"application_type\":\"new_applicant\",\"date_applied\":\"2025-10-22 00:00:00\",\"minor_last_name\":\"pilorin\",\"minor_first_name\":\"warren\",\"minor_middle_name\":\"bautista\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2022-10-22 00:00:00\",\"minor_age\":\"36\",\"minor_sex\":\"male\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"49 santol\",\"minor_barangay\":\"anonang\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":null,\"guardian_mobile_no\":\"09506440263\",\"guardian_email_address\":\"bautista.noly16@gmail.com\",\"minor_educational_attainment\":\"kindergarten\",\"father_last_name\":\"BAUTISTA\",\"father_first_name\":\"NOLY\",\"father_middle_name\":\"CASTRO\",\"mother_last_name\":\"BAUTISTA\",\"mother_first_name\":\"NOLY\",\"mother_middle_name\":\"OLIVO\",\"guardian_last_name\":\"BAUTISTA\",\"guardian_first_name\":\"NOLY\",\"guardian_middle_name\":\"OLIVO\",\"is_pwd_minor\":false,\"is_daycare_student\":false,\"accomplished_by\":\"applicant\",\"representative_name\":null,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"name_of_reporting_unit\":null,\"control_no\":null,\"doctor_certified_by\":null,\"license_no_physician\":null,\"pwd_type_of_disability\":null,\"pwd_cause_of_disability\":null,\"id\":30}', 'http://127.0.0.1:8000/submit-minor-form', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36', NULL, '2025-10-21 18:52:14', '2025-10-21 18:52:14'),
(41, 'App\\Models\\User', 8, 'created', 'App\\Models\\Minor', 31, '[]', '{\"application_type\":\"new_applicant\",\"date_applied\":\"2025-10-22 00:00:00\",\"minor_last_name\":\"pilorin\",\"minor_first_name\":\"vanessa\",\"minor_middle_name\":\"bautista\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2020-10-22 00:00:00\",\"minor_age\":\"60\",\"minor_sex\":\"female\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"22 sampaoc\",\"minor_barangay\":\"bacag\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":null,\"guardian_mobile_no\":\"09506440263\",\"guardian_email_address\":\"bautista.noly16@gmail.com\",\"minor_educational_attainment\":\"none\",\"father_last_name\":\"BAUTISTA\",\"father_first_name\":\"NOLY\",\"father_middle_name\":\"CASTRO\",\"mother_last_name\":\"BAUTISTA\",\"mother_first_name\":\"NOLY\",\"mother_middle_name\":\"OLIVO\",\"guardian_last_name\":\"BAUTISTA\",\"guardian_first_name\":\"NOLY\",\"guardian_middle_name\":\"OLIVO\",\"is_pwd_minor\":false,\"is_daycare_student\":false,\"accomplished_by\":\"applicant\",\"representative_name\":null,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"name_of_reporting_unit\":null,\"control_no\":null,\"doctor_certified_by\":null,\"license_no_physician\":null,\"pwd_type_of_disability\":null,\"pwd_cause_of_disability\":null,\"id\":31}', 'http://127.0.0.1:8000/submit-minor-form', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36', NULL, '2025-10-21 18:58:38', '2025-10-21 18:58:38'),
(42, 'App\\Models\\User', 8, 'created', 'App\\Models\\Minor', 32, '[]', '{\"application_type\":\"new_applicant\",\"date_applied\":\"2025-10-26 00:00:00\",\"minor_last_name\":\"bautista\",\"minor_first_name\":\"banjo\",\"minor_middle_name\":\"olivo\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2022-10-26 00:00:00\",\"minor_age\":\"36\",\"minor_sex\":\"male\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"53 sampaloc\",\"minor_barangay\":\"bantog\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":\"N\\/A\",\"guardian_mobile_no\":\"09506440265\",\"guardian_email_address\":\"bautistanoly16@gmail.com\",\"minor_educational_attainment\":\"kindergarten\",\"father_last_name\":\"BAUTISTA\",\"father_first_name\":\"NOLY\",\"father_middle_name\":\"castro\",\"mother_last_name\":\"BAUTISTA\",\"mother_first_name\":\"adelaida\",\"mother_middle_name\":\"olivo\",\"guardian_last_name\":\"BAUTISTA\",\"guardian_first_name\":\"adelaida\",\"guardian_middle_name\":\"olivo\",\"is_pwd_minor\":true,\"is_daycare_student\":true,\"daycare_actual_weight_date\":\"2025-10-26 00:00:00\",\"daycare_weight_kg\":\"15\",\"daycare_height_cm\":\"87\",\"daycare_weight_for_age\":\"Normal Weight\",\"daycare_height_for_age\":\"Normal Height\",\"daycare_weight_for_height\":\"Severely Obese\",\"accomplished_by\":\"applicant\",\"processing_officer\":\"VICTOR MAGTANGGOL\",\"approving_officer\":\"JULIUS\",\"encoder\":\"asd\",\"name_of_reporting_unit\":\"NOLY BAUTISTA\",\"control_no\":\"56456\",\"doctor_certified_by\":\"3423\",\"license_no_physician\":\"23435\",\"pwd_type_of_disability\":\"\\\"[\\\\\\\"speech_and_language_impairment\\\\\\\"]\\\"\",\"pwd_cause_of_disability\":\"\\\"[\\\\\\\"heredity\\\\\\\"]\\\"\",\"id\":32}', 'http://127.0.0.1:8000/submit-minor-form', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36', NULL, '2025-10-26 08:10:29', '2025-10-26 08:10:29'),
(43, 'App\\Models\\User', 8, 'created', 'App\\Models\\Minor', 33, '[]', '{\"application_type\":\"new_applicant\",\"date_applied\":\"2025-10-26 00:00:00\",\"minor_last_name\":\"bautista\",\"minor_first_name\":\"benje\",\"minor_middle_name\":\"olivo\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2022-10-26 00:00:00\",\"minor_age\":\"36\",\"minor_sex\":\"female\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"37 santol\",\"minor_barangay\":\"bantog\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":null,\"guardian_mobile_no\":\"09506440262\",\"guardian_email_address\":\"bautistanoly16@gmail.com\",\"minor_educational_attainment\":\"kindergarten\",\"father_last_name\":\"BAUTISTA\",\"father_first_name\":\"NOLY\",\"father_middle_name\":\"castro\",\"mother_last_name\":\"BAUTISTA\",\"mother_first_name\":\"NOLY\",\"mother_middle_name\":\"olivo\",\"guardian_last_name\":\"BAUTISTA\",\"guardian_first_name\":\"NOLY\",\"guardian_middle_name\":\"olivo\",\"is_pwd_minor\":true,\"is_daycare_student\":true,\"daycare_actual_weight_date\":\"2025-10-26 00:00:00\",\"daycare_weight_kg\":\"14\",\"daycare_height_cm\":\"87\",\"daycare_weight_for_age\":\"Normal Weight\",\"daycare_height_for_age\":\"Normal Height\",\"daycare_weight_for_height\":\"Overweight\",\"accomplished_by\":\"applicant\",\"processing_officer\":\"JOEL\",\"approving_officer\":\"JULIUS\",\"encoder\":\"ALEXIS\",\"name_of_reporting_unit\":\"NOLY BAUTISTA\",\"control_no\":\"09089993618\",\"doctor_certified_by\":\"3243\",\"license_no_physician\":\"23435\",\"pwd_type_of_disability\":\"\\\"[\\\\\\\"deaf_or_hard_of_hearing\\\\\\\"]\\\"\",\"pwd_cause_of_disability\":\"\\\"[\\\\\\\"heredity\\\\\\\"]\\\"\",\"id\":33}', 'http://127.0.0.1:8000/submit-minor-form', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36', NULL, '2025-10-26 08:46:30', '2025-10-26 08:46:30'),
(44, 'App\\Models\\User', 8, 'created', 'App\\Models\\Minor', 34, '[]', '{\"application_type\":\"new_applicant\",\"date_applied\":\"2025-10-26 00:00:00\",\"minor_last_name\":\"Delacruz\",\"minor_first_name\":\"lynette\",\"minor_middle_name\":\"Santos\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2021-07-19 00:00:00\",\"minor_age\":\"51\",\"minor_sex\":\"female\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"33 Samapaloc\",\"minor_barangay\":\"bantog\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":null,\"guardian_mobile_no\":\"09090909090\",\"guardian_email_address\":\"xtraspicyhotfinesytmaria@gmail.com\",\"minor_educational_attainment\":\"kindergarten\",\"father_last_name\":\"Delacruz\",\"father_first_name\":\"Pedring\",\"father_middle_name\":\"penduco\",\"mother_last_name\":\"Santos\",\"mother_first_name\":\"Maria\",\"mother_middle_name\":\"Galang\",\"guardian_last_name\":\"Santos\",\"guardian_first_name\":\"Maria\",\"guardian_middle_name\":\"Galang\",\"is_pwd_minor\":true,\"is_daycare_student\":true,\"daycare_actual_weight_date\":\"2025-10-26 00:00:00\",\"daycare_weight_kg\":\"15\",\"daycare_height_cm\":\"87\",\"daycare_weight_for_age\":\"Normal Weight\",\"daycare_height_for_age\":\"Stunted\",\"daycare_weight_for_height\":\"Obese\",\"accomplished_by\":\"guardian\",\"processing_officer\":\"JOEL\",\"approving_officer\":\"JULIUS REPOLLO\",\"encoder\":\"ALEXIS\",\"name_of_reporting_unit\":\"BANJO\",\"control_no\":\"09089993618\",\"doctor_certified_by\":\"N\\/A\",\"license_no_physician\":\"true\",\"pwd_type_of_disability\":\"\\\"[\\\\\\\"intellectual_disability\\\\\\\"]\\\"\",\"pwd_cause_of_disability\":\"\\\"[\\\\\\\"heredity\\\\\\\"]\\\"\",\"id\":34}', 'http://127.0.0.1:8000/submit-minor-form', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36', NULL, '2025-10-26 10:46:27', '2025-10-26 10:46:27'),
(45, 'App\\Models\\User', 3, 'created', 'App\\Models\\Minor', 35, '[]', '{\"application_type\":\"new_applicant\",\"date_applied\":\"2025-11-10 00:00:00\",\"minor_last_name\":\"sison\",\"minor_first_name\":\"kyle\",\"minor_middle_name\":\"ostrad\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2022-11-10 00:00:00\",\"minor_age\":\"36\",\"minor_sex\":\"male\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"24 mapel street\",\"minor_barangay\":\"bantog\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":null,\"guardian_mobile_no\":\"09783487374\",\"guardian_email_address\":null,\"minor_educational_attainment\":\"daycare\",\"father_last_name\":\"sison\",\"father_first_name\":\"juan\",\"father_middle_name\":\"tawan\",\"mother_last_name\":\"sison\",\"mother_first_name\":\"lisa\",\"mother_middle_name\":\"santos\",\"guardian_last_name\":\"sison\",\"guardian_first_name\":\"lisa\",\"guardian_middle_name\":\"santos\",\"is_pwd_minor\":false,\"is_daycare_student\":true,\"daycare_actual_weight_date\":\"2025-11-10 00:00:00\",\"daycare_weight_kg\":\"45\",\"daycare_height_cm\":\"76\",\"daycare_weight_for_age\":\"Possible Risk of Overweight\",\"daycare_height_for_age\":\"Severely Stunted\",\"daycare_weight_for_height\":\"Severely Obese\",\"accomplished_by\":\"applicant\",\"representative_name\":null,\"license_no\":null,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"name_of_reporting_unit\":null,\"control_no\":null,\"doctor_certified_by\":null,\"license_no_physician\":null,\"pwd_type_of_disability\":null,\"pwd_cause_of_disability\":null,\"id\":35}', 'http://127.0.0.1:8000/submit-minor-form', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-10 06:09:44', '2025-11-10 06:09:44'),
(46, 'App\\Models\\User', 3, 'created', 'App\\Models\\Minor', 36, '[]', '{\"application_type\":\"new_applicant\",\"date_applied\":\"2025-11-10 00:00:00\",\"minor_last_name\":\"amber\",\"minor_first_name\":\"young\",\"minor_middle_name\":\"walker\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2022-11-10 00:00:00\",\"minor_age\":\"36\",\"minor_sex\":\"male\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"34 peek street\",\"minor_barangay\":\"bacag\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":null,\"guardian_mobile_no\":\"09657575675\",\"guardian_email_address\":null,\"minor_educational_attainment\":\"daycare\",\"father_last_name\":\"amber\",\"father_first_name\":\"papi\",\"father_middle_name\":\"tran\",\"mother_last_name\":\"amber\",\"mother_first_name\":\"mami\",\"mother_middle_name\":\"tren\",\"guardian_last_name\":\"amber\",\"guardian_first_name\":\"mami\",\"guardian_middle_name\":\"walker\",\"is_pwd_minor\":false,\"is_daycare_student\":true,\"daycare_actual_weight_date\":\"2025-11-10 00:00:00\",\"daycare_weight_kg\":\"65\",\"daycare_height_cm\":\"78\",\"daycare_weight_for_age\":\"Possible Risk of Overweight\",\"daycare_height_for_age\":\"Severely Stunted\",\"daycare_weight_for_height\":\"Severely Obese\",\"accomplished_by\":\"applicant\",\"representative_name\":null,\"license_no\":null,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"name_of_reporting_unit\":null,\"control_no\":null,\"doctor_certified_by\":null,\"license_no_physician\":null,\"pwd_type_of_disability\":null,\"pwd_cause_of_disability\":null,\"id\":36}', 'http://127.0.0.1:8000/submit-minor-form', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-10 06:35:57', '2025-11-10 06:35:57'),
(47, 'App\\Models\\User', 3, 'created', 'App\\Models\\Minor', 37, '[]', '{\"application_type\":\"new_applicant\",\"date_applied\":\"2025-11-10 00:00:00\",\"minor_last_name\":\"walker\",\"minor_first_name\":\"kisha\",\"minor_middle_name\":\"ramos\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2021-11-10 00:00:00\",\"minor_age\":\"48\",\"minor_sex\":\"male\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"45 kings\",\"minor_barangay\":\"bacag\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":null,\"guardian_mobile_no\":\"095064402786\",\"guardian_email_address\":null,\"minor_educational_attainment\":\"daycare\",\"father_last_name\":\"walker\",\"father_first_name\":\"your\",\"father_middle_name\":\"ken\",\"mother_last_name\":\"walker\",\"mother_first_name\":\"one\",\"mother_middle_name\":\"luna\",\"guardian_last_name\":\"walker\",\"guardian_first_name\":\"one\",\"guardian_middle_name\":\"luna\",\"is_pwd_minor\":false,\"is_daycare_student\":true,\"daycare_actual_weight_date\":\"2025-11-10 00:00:00\",\"daycare_weight_kg\":\"45\",\"daycare_height_cm\":\"78\",\"daycare_weight_for_age\":\"Possible Risk of Overweight\",\"daycare_height_for_age\":\"Severely Stunted\",\"daycare_weight_for_height\":\"Severely Obese\",\"accomplished_by\":\"applicant\",\"representative_name\":null,\"license_no\":null,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"name_of_reporting_unit\":null,\"control_no\":null,\"doctor_certified_by\":null,\"license_no_physician\":null,\"pwd_type_of_disability\":null,\"pwd_cause_of_disability\":null,\"id\":37}', 'http://127.0.0.1:8000/submit-minor-form', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-10 06:42:58', '2025-11-10 06:42:58'),
(48, 'App\\Models\\User', 3, 'created', 'App\\Models\\Minor', 38, '[]', '{\"application_type\":\"new_applicant\",\"date_applied\":\"2025-11-10 00:00:00\",\"minor_last_name\":\"calixtro\",\"minor_first_name\":\"bryan\",\"minor_middle_name\":\"lomboy\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2021-11-10 00:00:00\",\"minor_age\":\"48\",\"minor_sex\":\"male\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"55 bactad\",\"minor_barangay\":\"bacag\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":null,\"guardian_mobile_no\":null,\"guardian_email_address\":null,\"minor_educational_attainment\":\"daycare\",\"father_last_name\":\"calixtro\",\"father_first_name\":\"tom\",\"father_middle_name\":\"patajo\",\"mother_last_name\":\"calixtro\",\"mother_first_name\":\"lisa\",\"mother_middle_name\":\"alcaraz\",\"guardian_last_name\":\"calixtro\",\"guardian_first_name\":\"lisa\",\"guardian_middle_name\":\"lomboy\",\"is_pwd_minor\":false,\"is_daycare_student\":true,\"daycare_actual_weight_date\":\"2025-11-10 00:00:00\",\"daycare_weight_kg\":\"77\",\"daycare_height_cm\":\"87\",\"daycare_weight_for_age\":\"Possible Risk of Overweight\",\"daycare_height_for_age\":\"Stunted\",\"daycare_weight_for_height\":\"Severely Obese\",\"accomplished_by\":\"applicant\",\"representative_name\":null,\"license_no\":null,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"name_of_reporting_unit\":null,\"control_no\":null,\"doctor_certified_by\":null,\"license_no_physician\":null,\"pwd_type_of_disability\":null,\"pwd_cause_of_disability\":null,\"id\":38}', 'http://127.0.0.1:8000/submit-minor-form', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-10 08:36:12', '2025-11-10 08:36:12'),
(49, 'App\\Models\\User', 3, 'created', 'App\\Models\\Minor', 39, '[]', '{\"application_type\":\"new_applicant\",\"date_applied\":\"2025-11-10 00:00:00\",\"minor_last_name\":\"west\",\"minor_first_name\":\"jan\",\"minor_middle_name\":\"ornada\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2021-11-10 00:00:00\",\"minor_age\":\"48\",\"minor_sex\":\"male\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"21 bilbom\",\"minor_barangay\":\"bacag\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":null,\"guardian_mobile_no\":null,\"guardian_email_address\":null,\"minor_educational_attainment\":\"daycare\",\"father_last_name\":\"west\",\"father_first_name\":\"ben\",\"father_middle_name\":\"tron\",\"mother_last_name\":\"west\",\"mother_first_name\":\"trish\",\"mother_middle_name\":\"ornada\",\"guardian_last_name\":\"west\",\"guardian_first_name\":\"trish\",\"guardian_middle_name\":\"ornada\",\"is_pwd_minor\":false,\"is_daycare_student\":true,\"daycare_actual_weight_date\":\"2025-11-10 00:00:00\",\"daycare_weight_kg\":\"45\",\"daycare_height_cm\":\"77\",\"daycare_weight_for_age\":\"Possible Risk of Overweight\",\"daycare_height_for_age\":\"Severely Stunted\",\"daycare_weight_for_height\":\"Severely Obese\",\"accomplished_by\":\"applicant\",\"representative_name\":null,\"license_no\":null,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"name_of_reporting_unit\":null,\"control_no\":null,\"doctor_certified_by\":null,\"license_no_physician\":null,\"pwd_type_of_disability\":null,\"pwd_cause_of_disability\":null,\"id\":39}', 'http://127.0.0.1:8000/submit-minor-form', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-10 08:51:40', '2025-11-10 08:51:40');
INSERT INTO `audits` (`id`, `user_type`, `user_id`, `event`, `auditable_type`, `auditable_id`, `old_values`, `new_values`, `url`, `ip_address`, `user_agent`, `tags`, `created_at`, `updated_at`) VALUES
(50, 'App\\Models\\User', 3, 'created', 'App\\Models\\Minor', 40, '[]', '{\"application_type\":\"new_applicant\",\"date_applied\":\"2025-11-10 00:00:00\",\"minor_last_name\":\"TRY\",\"minor_first_name\":\"TRY\",\"minor_middle_name\":\"TRY\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2025-11-10 00:00:00\",\"minor_age\":\"0\",\"minor_sex\":\"male\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"321 TREE\",\"minor_barangay\":\"bacag\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":null,\"guardian_mobile_no\":\"09506440263\",\"guardian_email_address\":\"bautista.noly16@gmail.com\",\"minor_educational_attainment\":\"daycare\",\"father_last_name\":\"BAUTISTA\",\"father_first_name\":\"NOLY\",\"father_middle_name\":null,\"mother_last_name\":\"BAUTISTA\",\"mother_first_name\":\"NOLY\",\"mother_middle_name\":null,\"guardian_last_name\":\"BAUTISTA\",\"guardian_first_name\":\"NOLY\",\"guardian_middle_name\":null,\"is_pwd_minor\":false,\"is_daycare_student\":false,\"accomplished_by\":\"applicant\",\"representative_name\":null,\"license_no\":null,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"name_of_reporting_unit\":null,\"control_no\":null,\"doctor_certified_by\":null,\"license_no_physician\":null,\"pwd_type_of_disability\":null,\"pwd_cause_of_disability\":null,\"id\":40}', 'http://127.0.0.1:8000/submit-minor-form', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-10 09:00:43', '2025-11-10 09:00:43'),
(51, NULL, NULL, 'created', 'App\\Models\\Minor', 41, '[]', '{\"application_type\":\"new_applicant\",\"date_applied\":\"2025-11-13 00:00:00\",\"minor_last_name\":\"fontanila\",\"minor_first_name\":\"joel\",\"minor_middle_name\":\"untalan\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2023-11-13 00:00:00\",\"minor_age\":\"24\",\"minor_sex\":\"male\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"66 santol\",\"minor_barangay\":\"anonang\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":null,\"guardian_mobile_no\":\"09506440263\",\"guardian_email_address\":\"bauly16@gmail.com\",\"minor_educational_attainment\":\"daycare\",\"father_last_name\":\"BAUTISTA\",\"father_first_name\":\"NOLY\",\"father_middle_name\":null,\"mother_last_name\":\"BAUTISTA\",\"mother_first_name\":\"NOLY\",\"mother_middle_name\":null,\"guardian_last_name\":\"BAUTISTA\",\"guardian_first_name\":\"NOLY\",\"guardian_middle_name\":null,\"is_pwd_minor\":false,\"is_daycare_student\":true,\"daycare_actual_weight_date\":\"2025-11-13 00:00:00\",\"daycare_weight_kg\":\"45\",\"daycare_height_cm\":\"55\",\"daycare_weight_for_age\":\"Possible Risk of Overweight\",\"daycare_height_for_age\":\"Severely Stunted\",\"daycare_weight_for_height\":\"Severely Obese\",\"accomplished_by\":\"applicant\",\"representative_name\":null,\"license_no\":null,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"name_of_reporting_unit\":null,\"control_no\":null,\"doctor_certified_by\":null,\"license_no_physician\":null,\"pwd_type_of_disability\":null,\"pwd_cause_of_disability\":null,\"id\":41}', 'http://127.0.0.1:8000/submit-minor-form', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-13 08:54:50', '2025-11-13 08:54:50'),
(52, NULL, NULL, 'created', 'App\\Models\\Minor', 42, '[]', '{\"application_type\":\"new_applicant\",\"date_applied\":\"2025-11-13 00:00:00\",\"minor_last_name\":\"domingo\",\"minor_first_name\":\"jane\",\"minor_middle_name\":\"santos\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2022-11-13 00:00:00\",\"minor_age\":\"36\",\"minor_sex\":\"female\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"54 santos\",\"minor_barangay\":\"anonang\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":null,\"guardian_mobile_no\":\"09506440263\",\"guardian_email_address\":\"bautisoly16@gmail.com\",\"minor_educational_attainment\":\"daycare\",\"father_last_name\":\"BAUTISTA\",\"father_first_name\":\"NOLY\",\"father_middle_name\":null,\"mother_last_name\":\"BAUTISTA\",\"mother_first_name\":\"NOLY\",\"mother_middle_name\":null,\"guardian_last_name\":\"BAUTISTA\",\"guardian_first_name\":\"NOLY\",\"guardian_middle_name\":null,\"is_pwd_minor\":0,\"is_daycare_student\":1,\"daycare_actual_weight_date\":\"2025-11-13 00:00:00\",\"daycare_weight_kg\":\"34\",\"daycare_height_cm\":\"65\",\"daycare_weight_for_age\":\"Possible Risk of Overweight\",\"daycare_height_for_age\":\"Severely Stunted\",\"daycare_weight_for_height\":\"Severely Obese\",\"accomplished_by\":\"applicant\",\"representative_name\":null,\"license_no\":null,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"name_of_reporting_unit\":null,\"control_no\":null,\"doctor_certified_by\":null,\"license_no_physician\":null,\"daycare_center\":\"Bactad East CDC\",\"pwd_type_of_disability\":null,\"pwd_cause_of_disability\":null,\"id\":42}', 'http://127.0.0.1:8000/submit-minor-form', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-13 09:12:53', '2025-11-13 09:12:53'),
(53, 'App\\Models\\User', 1, 'deleted', 'App\\Models\\Minor', 2, '{\"id\":2,\"application_type\":\"new_applicant\",\"date_applied\":\"2025-07-08\",\"minor_last_name\":\"bautista\",\"minor_first_name\":\"aida\",\"minor_middle_name\":\"olivo\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2025-02-12\",\"minor_age\":4,\"minor_sex\":\"female\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"Bani Pangasinan\",\"minor_barangay\":\"GUISET NORTE\",\"minor_municipality_city\":\"Bani\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"1\",\"guardian_landline_no\":null,\"guardian_mobile_no\":\"+639506440263\",\"guardian_email_address\":\"bautista.noly16@gmail.com\",\"minor_educational_attainment\":\"none\",\"minor_other_educational_attainment\":null,\"daycare_center\":\"Bactad East CDC\",\"father_last_name\":\"BAUTISTA\",\"father_first_name\":\"NOLY\",\"father_middle_name\":\"CASTRO\",\"mother_last_name\":\"BAUTISTA\",\"mother_first_name\":\"NOLY\",\"mother_middle_name\":\"OLIVO\",\"guardian_last_name\":\"BAUTISTA\",\"guardian_first_name\":\"NOLY\",\"guardian_middle_name\":\"OLIVO\",\"is_pwd_minor\":1,\"pwd_registration_status\":\"first_time\",\"pwd_number\":null,\"pwd_type_of_disability\":\"[\\\"deaf_or_hard_of_hearing\\\"]\",\"pwd_cause_of_disability\":\"[\\\"down_syndrome\\\"]\",\"pwd_other_disability_cause\":null,\"is_daycare_student\":1,\"is_archived\":1,\"daycare_actual_weight_date\":\"2025-07-08\",\"daycare_weight_kg\":\"34.00\",\"daycare_height_cm\":\"34.00\",\"daycare_weight_for_age\":\"N\\/A\",\"daycare_height_for_age\":\"N\\/A\",\"daycare_weight_for_height\":\"N\\/A\",\"accomplished_by\":\"applicant\",\"representative_name\":null,\"license_no\":null,\"processing_officer\":\"asdasd\",\"approving_officer\":\"asdasd\",\"encoder\":\"asdasd\",\"name_of_reporting_unit\":\"asdasd\",\"control_no\":\"asdas\",\"doctor_certified_by\":\"asdad\",\"license_no_physician\":null}', '[]', 'http://127.0.0.1:8000/staff/pwd-section/2/archive', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-13 20:05:04', '2025-11-13 20:05:04'),
(54, 'App\\Models\\User', 3, 'deleted', 'App\\Models\\Minor', 5, '{\"id\":5,\"application_type\":\"new_applicant\",\"date_applied\":\"2025-03-03\",\"minor_last_name\":\"sdasdas\",\"minor_first_name\":\"dsadasdasd\",\"minor_middle_name\":\"adasdasdasd\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2024-12-05\",\"minor_age\":7,\"minor_sex\":\"female\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"sdasdasd\",\"minor_barangay\":\"san_miguel\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":null,\"guardian_mobile_no\":\"+639506440263\",\"guardian_email_address\":\"bautista.noly16@gmail.com\",\"minor_educational_attainment\":\"vocational\",\"minor_other_educational_attainment\":null,\"daycare_center\":\"Bactad East CDC\",\"father_last_name\":\"BAUTISTA\",\"father_first_name\":\"NOLY\",\"father_middle_name\":\"sdadasdsds\",\"mother_last_name\":\"BAUTISTA\",\"mother_first_name\":\"NOLY\",\"mother_middle_name\":\"dasdssdasd\",\"guardian_last_name\":\"BAUTISTA\",\"guardian_first_name\":\"NOLY\",\"guardian_middle_name\":\"dsdsadsadas\",\"is_pwd_minor\":1,\"pwd_registration_status\":\"first_time\",\"pwd_number\":null,\"pwd_type_of_disability\":\"[\\\"mental_disability\\\"]\",\"pwd_cause_of_disability\":\"[\\\"congenital_inborn\\\"]\",\"pwd_other_disability_cause\":null,\"is_daycare_student\":1,\"is_archived\":0,\"daycare_actual_weight_date\":\"2025-07-09\",\"daycare_weight_kg\":\"23.00\",\"daycare_height_cm\":\"45.00\",\"daycare_weight_for_age\":\"N\\/A\",\"daycare_height_for_age\":\"N\\/A\",\"daycare_weight_for_height\":\"N\\/A\",\"accomplished_by\":\"applicant\",\"representative_name\":null,\"license_no\":null,\"processing_officer\":\"fvdsafsdf\",\"approving_officer\":\"asdasdas\",\"encoder\":\"dasdasd\",\"name_of_reporting_unit\":\"asd\",\"control_no\":\"dfsdf\",\"doctor_certified_by\":\"sdfsdf\",\"license_no_physician\":null}', '[]', 'http://127.0.0.1:8000/teacher/daycare-record/5/archive', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-16 11:11:53', '2025-11-16 11:11:53'),
(55, 'App\\Models\\User', 3, 'deleted', 'App\\Models\\Minor', 6, '{\"id\":6,\"application_type\":\"new_applicant\",\"date_applied\":\"2025-07-10\",\"minor_last_name\":\"dasdfffdgf\",\"minor_first_name\":\"hghgfhgf\",\"minor_middle_name\":\"jhfgjfgjghj\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2021-10-21\",\"minor_age\":44,\"minor_sex\":\"male\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"ghgfh\",\"minor_barangay\":\"anonas\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":null,\"guardian_mobile_no\":\"+639506440263\",\"guardian_email_address\":\"bautista.noly16@gmail.com\",\"minor_educational_attainment\":\"none\",\"minor_other_educational_attainment\":null,\"daycare_center\":\"Bactad East CDC\",\"father_last_name\":\"BAUTISTA\",\"father_first_name\":\"NOLY\",\"father_middle_name\":\"fdhdfh\",\"mother_last_name\":\"BAUTISTA\",\"mother_first_name\":\"NOLY\",\"mother_middle_name\":\"dfhgdfh\",\"guardian_last_name\":\"BAUTISTA\",\"guardian_first_name\":\"NOLY\",\"guardian_middle_name\":\"fdhd\",\"is_pwd_minor\":1,\"pwd_registration_status\":\"first_time\",\"pwd_number\":null,\"pwd_type_of_disability\":\"[\\\"deaf_or_hard_of_hearing\\\"]\",\"pwd_cause_of_disability\":\"[\\\"acquired\\\"]\",\"pwd_other_disability_cause\":null,\"is_daycare_student\":1,\"is_archived\":0,\"daycare_actual_weight_date\":\"2025-07-17\",\"daycare_weight_kg\":\"14.00\",\"daycare_height_cm\":\"88.00\",\"daycare_weight_for_age\":\"Normal Weight\",\"daycare_height_for_age\":\"Stunted\",\"daycare_weight_for_height\":\"Obese\",\"accomplished_by\":\"applicant\",\"representative_name\":null,\"license_no\":null,\"processing_officer\":\"dfhdfh\",\"approving_officer\":\"dfhdfh\",\"encoder\":\"dhdfh\",\"name_of_reporting_unit\":\"dfhdfh\",\"control_no\":\"dfhdfh\",\"doctor_certified_by\":\"dfhdfh\",\"license_no_physician\":null}', '[]', 'http://127.0.0.1:8000/teacher/daycare-record/6/archive', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-16 11:30:47', '2025-11-16 11:30:47'),
(56, NULL, NULL, 'created', 'App\\Models\\Minor', 43, '[]', '{\"application_type\":\"new_applicant\",\"date_applied\":\"2025-11-18 00:00:00\",\"minor_last_name\":\"cacal\",\"minor_first_name\":\"shina\",\"minor_middle_name\":\"castro\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2009-11-18 00:00:00\",\"minor_age\":\"192\",\"minor_sex\":\"male\",\"minor_civil_status\":\"single\",\"minor_house_no_street\":\"11 capitol\",\"minor_barangay\":\"anonang\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":null,\"guardian_mobile_no\":\"0956454564\",\"guardian_email_address\":\"castro@gmail\",\"minor_educational_attainment\":\"junior_high_school\",\"father_last_name\":\"cacal\",\"father_first_name\":\"nestor\",\"father_middle_name\":\"santos\",\"mother_last_name\":\"cacal\",\"mother_first_name\":\"beth\",\"mother_middle_name\":\"luna\",\"guardian_last_name\":\"cacal\",\"guardian_first_name\":\"beth\",\"guardian_middle_name\":\"castro\",\"is_pwd_minor\":1,\"is_daycare_student\":0,\"accomplished_by\":\"applicant\",\"processing_officer\":null,\"approving_officer\":\"LIibeth dasig doriano\",\"encoder\":null,\"name_of_reporting_unit\":null,\"control_no\":null,\"doctor_certified_by\":null,\"license_no_physician\":null,\"pwd_type_of_disability\":\"\\\"[\\\\\\\"Cancer(Ra11215)\\\\\\\"]\\\"\",\"pwd_cause_of_disability\":\"\\\"[\\\\\\\"Injury\\\\\\\"]\\\"\",\"id\":43}', 'http://127.0.0.1:8000/submit-minor-form', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-18 10:37:20', '2025-11-18 10:37:20'),
(57, 'App\\Models\\User', 8, 'created', 'App\\Models\\Announcement', 15, '[]', '{\"title\":\"PWD PROGRAMS\",\"description\":\"COME AND HAVE A FREE CONSULTATION ON YOU HEALTH\",\"imageUrl\":\"announcement_images\\/Kaajebbl4f9wcgal1YjVeDy7591fAmyeYJfeZMrM.jpg\",\"date\":\"Nov 22, 2025\",\"due_date\":\"2025-11-30\",\"id\":15}', 'http://127.0.0.1:8000/admin/announcement-programs', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-21 18:19:45', '2025-11-21 18:19:45'),
(58, 'App\\Models\\User', 8, 'deleted', 'App\\Models\\Minor', 20, '{\"id\":20,\"application_type\":\"new_applicant\",\"date_applied\":\"2025-02-10\",\"minor_last_name\":\"daus\",\"minor_first_name\":\"jayden\",\"minor_middle_name\":\"h.\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2021-12-22\",\"minor_birthplace\":\"Urdaneta City\",\"minor_age\":43,\"minor_sex\":\"male\",\"minor_civil_status\":\"single\",\"minor_religion\":\"Roman Catholic\",\"minor_house_no_street\":\"zone 3\",\"minor_barangay\":\"baket_baket\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":\"01946478134\",\"guardian_mobile_no\":\"01843243264\",\"guardian_email_address\":null,\"minor_educational_attainment\":\"none\",\"minor_other_educational_attainment\":null,\"daycare_center\":\"Bactad East CDC\",\"father_last_name\":\"daus\",\"father_first_name\":\"andres\",\"father_middle_name\":\"l\",\"mother_last_name\":\"daus\",\"mother_first_name\":\"hershy\",\"mother_middle_name\":\"h\",\"guardian_last_name\":null,\"guardian_first_name\":null,\"guardian_middle_name\":null,\"is_pwd_minor\":0,\"pwd_registration_status\":null,\"pwd_number\":null,\"pwd_type_of_disability\":null,\"pwd_cause_of_disability\":null,\"pwd_other_disability_cause\":null,\"is_daycare_student\":1,\"is_archived\":0,\"daycare_actual_weight_date\":\"2025-02-10\",\"daycare_weight_kg\":\"16.70\",\"daycare_height_cm\":\"102.90\",\"daycare_weight_for_age\":\"Possible Risk of Overweight\",\"daycare_height_for_age\":\"Normal Height\",\"daycare_weight_for_height\":\"Overweight\",\"accomplished_by\":\"guardian\",\"representative_name\":null,\"license_no\":null,\"processing_officer_last_name\":null,\"processing_officer_first_name\":null,\"processing_officer_middle_name\":null,\"approving_officer_last_name\":null,\"approving_officer_first_name\":null,\"approving_officer_middle_name\":null,\"encoder_last_name\":null,\"encoder_first_name\":null,\"encoder_middle_name\":null,\"name_of_reporting_unit\":null,\"control_no\":null,\"doctor_last_name\":null,\"doctor_first_name\":null,\"doctor_middle_name\":null,\"license_no_physician\":null}', '[]', 'http://127.0.0.1:8000/admin/children-records/20/archive', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-22 02:48:32', '2025-11-22 02:48:32'),
(59, 'App\\Models\\User', 8, 'restored', 'App\\Models\\Minor', 20, '[]', '{\"id\":20,\"application_type\":\"new_applicant\",\"date_applied\":\"2025-02-10\",\"minor_last_name\":\"daus\",\"minor_first_name\":\"jayden\",\"minor_middle_name\":\"h.\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2021-12-22\",\"minor_birthplace\":\"Urdaneta City\",\"minor_age\":43,\"minor_sex\":\"male\",\"minor_civil_status\":\"single\",\"minor_religion\":\"Roman Catholic\",\"minor_house_no_street\":\"zone 3\",\"minor_barangay\":\"baket_baket\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":\"01946478134\",\"guardian_mobile_no\":\"01843243264\",\"guardian_email_address\":null,\"minor_educational_attainment\":\"none\",\"minor_other_educational_attainment\":null,\"daycare_center\":\"Bactad East CDC\",\"father_last_name\":\"daus\",\"father_first_name\":\"andres\",\"father_middle_name\":\"l\",\"mother_last_name\":\"daus\",\"mother_first_name\":\"hershy\",\"mother_middle_name\":\"h\",\"guardian_last_name\":null,\"guardian_first_name\":null,\"guardian_middle_name\":null,\"is_pwd_minor\":0,\"pwd_registration_status\":null,\"pwd_number\":null,\"pwd_type_of_disability\":null,\"pwd_cause_of_disability\":null,\"pwd_other_disability_cause\":null,\"is_daycare_student\":1,\"is_archived\":0,\"daycare_actual_weight_date\":\"2025-02-10\",\"daycare_weight_kg\":\"16.70\",\"daycare_height_cm\":\"102.90\",\"daycare_weight_for_age\":\"Possible Risk of Overweight\",\"daycare_height_for_age\":\"Normal Height\",\"daycare_weight_for_height\":\"Overweight\",\"accomplished_by\":\"guardian\",\"representative_name\":null,\"license_no\":null,\"processing_officer_last_name\":null,\"processing_officer_first_name\":null,\"processing_officer_middle_name\":null,\"approving_officer_last_name\":null,\"approving_officer_first_name\":null,\"approving_officer_middle_name\":null,\"encoder_last_name\":null,\"encoder_first_name\":null,\"encoder_middle_name\":null,\"name_of_reporting_unit\":null,\"control_no\":null,\"doctor_last_name\":null,\"doctor_first_name\":null,\"doctor_middle_name\":null,\"license_no_physician\":null}', 'http://127.0.0.1:8000/admin/archived-records/20/restore', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-22 03:25:25', '2025-11-22 03:25:25'),
(60, 'App\\Models\\User', 1, 'created', 'App\\Models\\AidAssistance', 10, '[]', '{\"date_given\":\"2025-11-22\",\"receiver_name\":\"nel\",\"quantity\":\"1\",\"assistance_type\":\"Food Pack\",\"notes\":\"for bagyo\",\"minor_id\":7,\"id\":10}', 'http://127.0.0.1:8000/staff/aid-monitoring/7/aid', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-22 10:23:36', '2025-11-22 10:23:36'),
(61, 'App\\Models\\User', 1, 'updated', 'App\\Models\\Minor', 7, '{\"minor_age\":12,\"minor_sex\":\"male\",\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"doctor_certified_by\":null}', '{\"minor_age\":16.359039085100694,\"minor_sex\":\"female\",\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"doctor_certified_by\":null}', 'http://127.0.0.1:8000/staff/children-records/7', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-22 10:30:29', '2025-11-22 10:30:29'),
(62, 'App\\Models\\User', 1, 'updated', 'App\\Models\\Minor', 7, '{\"minor_age\":12,\"minor_sex\":\"male\",\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"doctor_certified_by\":null}', '{\"minor_age\":16.359043443474924,\"minor_sex\":\"female\",\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"doctor_certified_by\":null}', 'http://127.0.0.1:8000/staff/children-records/7', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-22 10:30:40', '2025-11-22 10:30:40'),
(63, 'App\\Models\\User', 1, 'updated', 'App\\Models\\Minor', 11, '{\"minor_age\":58,\"minor_sex\":\"female\",\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null}', '{\"minor_age\":62.159049365667826,\"minor_sex\":\"male\",\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null}', 'http://127.0.0.1:8000/staff/children-records/11', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-22 10:30:55', '2025-11-22 10:30:55'),
(64, 'App\\Models\\User', 1, 'updated', 'App\\Models\\Minor', 7, '{\"minor_age\":12,\"minor_sex\":\"male\",\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"doctor_certified_by\":null}', '{\"minor_age\":16.3797896898179,\"minor_sex\":\"female\",\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"doctor_certified_by\":null}', 'http://127.0.0.1:8000/staff/children-records/7', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-23 01:26:55', '2025-11-23 01:26:55'),
(65, 'App\\Models\\User', 1, 'updated', 'App\\Models\\Minor', 11, '{\"minor_age\":58,\"minor_sex\":\"female\",\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null}', '{\"minor_age\":62.1797987759973,\"minor_sex\":\"male\",\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null}', 'http://127.0.0.1:8000/staff/children-records/11', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-23 01:27:18', '2025-11-23 01:27:18'),
(66, 'App\\Models\\User', 1, 'updated', 'App\\Models\\Minor', 7, '{\"minor_last_name\":\"ahgkgkhj\",\"minor_first_name\":\"klhjglghl\",\"minor_middle_name\":\"ghkgfhk\",\"minor_age\":12,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"doctor_certified_by\":null}', '{\"minor_last_name\":\"Kaberkin\",\"minor_first_name\":\"Marc\",\"minor_middle_name\":\"Zues\",\"minor_age\":16.379819092029706,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"doctor_certified_by\":null}', 'http://127.0.0.1:8000/staff/children-records/7', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-23 01:28:11', '2025-11-23 01:28:11'),
(67, 'App\\Models\\User', 1, 'updated', 'App\\Models\\Minor', 7, '{\"minor_last_name\":\"ahgkgkhj\",\"minor_first_name\":\"klhjglghl\",\"minor_middle_name\":\"ghkgfhk\",\"minor_age\":12,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"doctor_certified_by\":null}', '{\"minor_last_name\":\"Walker\",\"minor_first_name\":\"Alan\",\"minor_middle_name\":\"Tan\",\"minor_age\":16.379925378698687,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"doctor_certified_by\":null}', 'http://127.0.0.1:8000/staff/children-records/7', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-23 01:32:46', '2025-11-23 01:32:46'),
(68, 'App\\Models\\User', 1, 'updated', 'App\\Models\\Minor', 7, '{\"minor_last_name\":\"ahgkgkhj\",\"minor_first_name\":\"klhjglghl\",\"minor_middle_name\":\"ghkgfhk\",\"minor_age\":12,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"doctor_certified_by\":null}', '{\"minor_last_name\":\"Canor\",\"minor_first_name\":\"Nicole\",\"minor_middle_name\":\"Daus\",\"minor_age\":16.38019587021296,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"doctor_certified_by\":null}', 'http://127.0.0.1:8000/staff/children-records/7', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-23 01:44:27', '2025-11-23 01:44:27'),
(69, 'App\\Models\\User', 1, 'updated', 'App\\Models\\Minor', 7, '{\"minor_last_name\":\"ahgkgkhj\",\"minor_age\":12,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"doctor_certified_by\":null}', '{\"minor_last_name\":\"castor\",\"minor_age\":16.380291281116897,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"doctor_certified_by\":null}', 'http://127.0.0.1:8000/staff/children-records/7', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-23 01:48:35', '2025-11-23 01:48:35'),
(70, 'App\\Models\\User', 1, 'updated', 'App\\Models\\Minor', 7, '{\"minor_first_name\":\"klhjglghl\",\"minor_age\":12,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"doctor_certified_by\":null}', '{\"minor_first_name\":\"maya\",\"minor_age\":16.38032322549383,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"doctor_certified_by\":null}', 'http://127.0.0.1:8000/staff/children-records/7', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-23 01:49:57', '2025-11-23 01:49:57'),
(71, 'App\\Models\\User', 1, 'updated', 'App\\Models\\Minor', 7, '{\"minor_last_name\":\"ahgkgkhj\",\"minor_age\":12,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"doctor_certified_by\":null}', '{\"minor_last_name\":\"Cacal\",\"minor_age\":16.380463089374228,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"doctor_certified_by\":null}', 'http://127.0.0.1:8000/staff/children-records/7', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-23 01:56:00', '2025-11-23 01:56:00'),
(72, 'App\\Models\\User', 8, 'created', 'App\\Models\\Task', 6, '[]', '{\"task_title\":\"Last Master List\",\"task_description\":\"Pass as soon as possible\",\"date_created\":\"2025-11-23 00:00:00\",\"due_date\":\"2025-12-08 00:00:00\",\"status\":\"active\",\"id\":6}', 'http://127.0.0.1:8000/admin/tasks', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-23 02:18:43', '2025-11-23 02:18:43'),
(73, 'App\\Models\\User', 3, 'updated', 'App\\Models\\Task', 6, '{\"status\":\"active\"}', '{\"status\":\"done\"}', 'http://127.0.0.1:8000/teacher/reminders-tasks/6/mark-done', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-23 02:19:21', '2025-11-23 02:19:21'),
(74, 'App\\Models\\User', 3, 'deleted', 'App\\Models\\Minor', 7, '{\"id\":7,\"application_type\":\"new_applicant\",\"date_applied\":\"2025-07-14\",\"minor_last_name\":\"ahgkgkhj\",\"minor_first_name\":\"klhjglghl\",\"minor_middle_name\":\"ghkgfhk\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2024-07-12\",\"minor_birthplace\":\"Urdaneta City\",\"minor_age\":12,\"minor_sex\":\"male\",\"minor_civil_status\":\"single\",\"minor_religion\":\"Roman Catholic\",\"minor_house_no_street\":\"34 sampaloc street\",\"minor_barangay\":\"San Miguel\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":null,\"guardian_mobile_no\":\"8968796789769\",\"guardian_email_address\":\"bautista.noly16@gmail.com\",\"minor_educational_attainment\":\"none\",\"minor_other_educational_attainment\":null,\"daycare_center\":\"Bactad East CDC\",\"father_last_name\":\"hkhjgk\",\"father_first_name\":\"kfgh\",\"father_middle_name\":\"fgkgfhk\",\"mother_last_name\":\"fgkfgkhf\",\"mother_first_name\":\"gfhkgfkgfk\",\"mother_middle_name\":\"gfhk\",\"guardian_last_name\":\"gkfgkfg\",\"guardian_first_name\":\"kgfkgfk\",\"guardian_middle_name\":\"fghkfgkfg\",\"is_pwd_minor\":1,\"pwd_registration_status\":\"first_time\",\"pwd_number\":null,\"pwd_type_of_disability\":\"\\\"[\\\\\\\"mental_disability\\\\\\\"]\\\"\",\"pwd_cause_of_disability\":\"\\\"[\\\\\\\"cerebral_palsy\\\\\\\"]\\\"\",\"pwd_other_disability_cause\":null,\"is_daycare_student\":1,\"is_archived\":0,\"daycare_actual_weight_date\":\"2025-07-14\",\"daycare_weight_kg\":\"12.00\",\"daycare_height_cm\":\"60.00\",\"daycare_weight_for_age\":\"Possible Risk of Overweight\",\"daycare_height_for_age\":\"Severely Stunted\",\"daycare_weight_for_height\":\"Severely Obese\",\"accomplished_by\":\"applicant\",\"representative_name\":null,\"license_no\":null,\"processing_officer_last_name\":null,\"processing_officer_first_name\":null,\"processing_officer_middle_name\":null,\"approving_officer_last_name\":null,\"approving_officer_first_name\":null,\"approving_officer_middle_name\":null,\"encoder_last_name\":null,\"encoder_first_name\":null,\"encoder_middle_name\":null,\"name_of_reporting_unit\":\"tertert\",\"control_no\":\"ertertg\",\"doctor_last_name\":null,\"doctor_first_name\":null,\"doctor_middle_name\":null,\"license_no_physician\":null}', '[]', 'http://127.0.0.1:8000/teacher/daycare-record/7/archive', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-23 02:21:27', '2025-11-23 02:21:27'),
(75, 'App\\Models\\User', 3, 'restored', 'App\\Models\\Minor', 7, '[]', '{\"id\":7,\"application_type\":\"new_applicant\",\"date_applied\":\"2025-07-14\",\"minor_last_name\":\"ahgkgkhj\",\"minor_first_name\":\"klhjglghl\",\"minor_middle_name\":\"ghkgfhk\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2024-07-12\",\"minor_birthplace\":\"Urdaneta City\",\"minor_age\":12,\"minor_sex\":\"male\",\"minor_civil_status\":\"single\",\"minor_religion\":\"Roman Catholic\",\"minor_house_no_street\":\"34 sampaloc street\",\"minor_barangay\":\"San Miguel\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":null,\"guardian_mobile_no\":\"8968796789769\",\"guardian_email_address\":\"bautista.noly16@gmail.com\",\"minor_educational_attainment\":\"none\",\"minor_other_educational_attainment\":null,\"daycare_center\":\"Bactad East CDC\",\"father_last_name\":\"hkhjgk\",\"father_first_name\":\"kfgh\",\"father_middle_name\":\"fgkgfhk\",\"mother_last_name\":\"fgkfgkhf\",\"mother_first_name\":\"gfhkgfkgfk\",\"mother_middle_name\":\"gfhk\",\"guardian_last_name\":\"gkfgkfg\",\"guardian_first_name\":\"kgfkgfk\",\"guardian_middle_name\":\"fghkfgkfg\",\"is_pwd_minor\":1,\"pwd_registration_status\":\"first_time\",\"pwd_number\":null,\"pwd_type_of_disability\":\"\\\"[\\\\\\\"mental_disability\\\\\\\"]\\\"\",\"pwd_cause_of_disability\":\"\\\"[\\\\\\\"cerebral_palsy\\\\\\\"]\\\"\",\"pwd_other_disability_cause\":null,\"is_daycare_student\":1,\"is_archived\":0,\"daycare_actual_weight_date\":\"2025-07-14\",\"daycare_weight_kg\":\"12.00\",\"daycare_height_cm\":\"60.00\",\"daycare_weight_for_age\":\"Possible Risk of Overweight\",\"daycare_height_for_age\":\"Severely Stunted\",\"daycare_weight_for_height\":\"Severely Obese\",\"accomplished_by\":\"applicant\",\"representative_name\":null,\"license_no\":null,\"processing_officer_last_name\":null,\"processing_officer_first_name\":null,\"processing_officer_middle_name\":null,\"approving_officer_last_name\":null,\"approving_officer_first_name\":null,\"approving_officer_middle_name\":null,\"encoder_last_name\":null,\"encoder_first_name\":null,\"encoder_middle_name\":null,\"name_of_reporting_unit\":\"tertert\",\"control_no\":\"ertertg\",\"doctor_last_name\":null,\"doctor_first_name\":null,\"doctor_middle_name\":null,\"license_no_physician\":null}', 'http://127.0.0.1:8000/teacher/archived/21/restore', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-23 02:21:36', '2025-11-23 02:21:36'),
(76, 'App\\Models\\User', 3, 'restored', 'App\\Models\\Minor', 6, '[]', '{\"id\":6,\"application_type\":\"new_applicant\",\"date_applied\":\"2025-07-10\",\"minor_last_name\":\"dasdfffdgf\",\"minor_first_name\":\"hghgfhgf\",\"minor_middle_name\":\"jhfgjfgjghj\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2021-10-21\",\"minor_birthplace\":\"Urdaneta City\",\"minor_age\":44,\"minor_sex\":\"male\",\"minor_civil_status\":\"single\",\"minor_religion\":\"Roman Catholic\",\"minor_house_no_street\":\"ghgfh\",\"minor_barangay\":\"anonas\",\"minor_municipality_city\":\"Urdaneta City\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"Ilocos Region (Region I)\",\"guardian_landline_no\":null,\"guardian_mobile_no\":\"+639506440263\",\"guardian_email_address\":\"bautista.noly16@gmail.com\",\"minor_educational_attainment\":\"none\",\"minor_other_educational_attainment\":null,\"daycare_center\":\"Bactad East CDC\",\"father_last_name\":\"BAUTISTA\",\"father_first_name\":\"NOLY\",\"father_middle_name\":\"fdhdfh\",\"mother_last_name\":\"BAUTISTA\",\"mother_first_name\":\"NOLY\",\"mother_middle_name\":\"dfhgdfh\",\"guardian_last_name\":\"BAUTISTA\",\"guardian_first_name\":\"NOLY\",\"guardian_middle_name\":\"fdhd\",\"is_pwd_minor\":1,\"pwd_registration_status\":\"first_time\",\"pwd_number\":null,\"pwd_type_of_disability\":\"[\\\"deaf_or_hard_of_hearing\\\"]\",\"pwd_cause_of_disability\":\"[\\\"acquired\\\"]\",\"pwd_other_disability_cause\":null,\"is_daycare_student\":1,\"is_archived\":0,\"daycare_actual_weight_date\":\"2025-07-17\",\"daycare_weight_kg\":\"14.00\",\"daycare_height_cm\":\"88.00\",\"daycare_weight_for_age\":\"Normal Weight\",\"daycare_height_for_age\":\"Stunted\",\"daycare_weight_for_height\":\"Obese\",\"accomplished_by\":\"applicant\",\"representative_name\":null,\"license_no\":null,\"processing_officer_last_name\":null,\"processing_officer_first_name\":null,\"processing_officer_middle_name\":null,\"approving_officer_last_name\":null,\"approving_officer_first_name\":null,\"approving_officer_middle_name\":null,\"encoder_last_name\":null,\"encoder_first_name\":null,\"encoder_middle_name\":null,\"name_of_reporting_unit\":\"dfhdfh\",\"control_no\":\"dfhdfh\",\"doctor_last_name\":null,\"doctor_first_name\":null,\"doctor_middle_name\":null,\"license_no_physician\":null}', 'http://127.0.0.1:8000/teacher/archived/19/restore', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-23 02:21:48', '2025-11-23 02:21:48'),
(77, 'App\\Models\\User', 8, 'updated', 'App\\Models\\Minor', 6, '{\"application_type\":\"new_applicant\",\"minor_first_name\":\"hghgfhgf\",\"minor_age\":44,\"minor_educational_attainment\":\"none\",\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"pwd_other_type_of_disability\":null,\"doctor_certified_by\":null,\"case_category\":null,\"assistive_devices_needed\":null}', '{\"application_type\":\"birth_registration\",\"minor_first_name\":\"timot\",\"minor_age\":49.0833473595243,\"minor_educational_attainment\":null,\"processing_officer\":null,\"approving_officer\":null,\"encoder\":null,\"pwd_other_type_of_disability\":null,\"doctor_certified_by\":null,\"case_category\":null,\"assistive_devices_needed\":null}', 'http://127.0.0.1:8000/admin/children-records/6', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-23 04:00:36', '2025-11-23 04:00:36'),
(78, 'App\\Models\\User', 8, 'updated', 'App\\Models\\Minor', 6, '{\"application_type\":\"new_applicant\",\"minor_first_name\":\"hghgfhgf\",\"minor_age\":44,\"minor_educational_attainment\":\"none\",\"pwd_type_of_disability\":\"[\\\"deaf_or_hard_of_hearing\\\"]\"}', '{\"application_type\":\"birth_registration\",\"minor_first_name\":\"timot\",\"minor_age\":49.08369875247029,\"minor_educational_attainment\":null,\"pwd_type_of_disability\":null}', 'http://127.0.0.1:8000/admin/children-records/6', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-23 04:15:47', '2025-11-23 04:15:47'),
(79, 'App\\Models\\User', 8, 'updated', 'App\\Models\\Minor', 6, '{\"application_type\":\"new_applicant\",\"minor_first_name\":\"hghgfhgf\",\"minor_educational_attainment\":\"none\",\"pwd_type_of_disability\":\"[\\\"deaf_or_hard_of_hearing\\\"]\"}', '{\"application_type\":\"birth_registration\",\"minor_first_name\":\"timot\",\"minor_educational_attainment\":null,\"pwd_type_of_disability\":null}', 'http://127.0.0.1:8000/admin/children-records/6', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-23 04:21:49', '2025-11-23 04:21:49'),
(80, 'App\\Models\\User', 8, 'updated', 'App\\Models\\Minor', 6, '{\"application_type\":\"new_applicant\",\"minor_first_name\":\"hghgfhgf\",\"minor_sex\":\"male\",\"minor_educational_attainment\":\"none\",\"pwd_type_of_disability\":\"[\\\"deaf_or_hard_of_hearing\\\"]\"}', '{\"application_type\":\"birth_registration\",\"minor_first_name\":\"timot\",\"minor_sex\":\"female\",\"minor_educational_attainment\":null,\"pwd_type_of_disability\":null}', 'http://127.0.0.1:8000/admin/children-records/6', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-23 04:22:30', '2025-11-23 04:22:30'),
(81, 'App\\Models\\User', 8, 'updated', 'App\\Models\\Minor', 6, '{\"application_type\":\"new_applicant\",\"minor_first_name\":\"hghgfhgf\",\"minor_educational_attainment\":\"none\",\"pwd_type_of_disability\":\"[\\\"deaf_or_hard_of_hearing\\\"]\"}', '{\"application_type\":\"birth_registration\",\"minor_first_name\":\"timot\",\"minor_educational_attainment\":null,\"pwd_type_of_disability\":null}', 'http://127.0.0.1:8000/admin/children-records/6', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-23 04:46:24', '2025-11-23 04:46:24'),
(82, 'App\\Models\\User', 8, 'updated', 'App\\Models\\Minor', 6, '{\"application_type\":\"new_applicant\",\"minor_first_name\":\"hghgfhgf\",\"minor_educational_attainment\":\"none\",\"pwd_type_of_disability\":\"[\\\"deaf_or_hard_of_hearing\\\"]\"}', '{\"application_type\":\"birth_registration\",\"minor_first_name\":\"timot\",\"minor_educational_attainment\":null,\"pwd_type_of_disability\":null}', 'http://127.0.0.1:8000/admin/children-records/6', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-23 04:49:08', '2025-11-23 04:49:08'),
(83, 'App\\Models\\User', 8, 'updated', 'App\\Models\\Minor', 6, '{\"application_type\":\"new_applicant\",\"date_applied\":\"2025-07-10\",\"minor_last_name\":\"dasdfffdgf\",\"minor_first_name\":\"hghgfhgf\",\"minor_middle_name\":\"jhfgjfgjghj\",\"minor_sex\":\"male\",\"minor_house_no_street\":\"ghgfh\",\"minor_educational_attainment\":\"none\",\"is_pwd_minor\":1,\"pwd_type_of_disability\":\"[\\\"deaf_or_hard_of_hearing\\\"]\"}', '{\"application_type\":\"birth_registration\",\"date_applied\":\"2025-11-23 00:00:00\",\"minor_last_name\":\"Pilorin\",\"minor_first_name\":\"Vanessa\",\"minor_middle_name\":\"Bautista\",\"minor_sex\":\"female\",\"minor_house_no_street\":\"Santol Street\",\"minor_educational_attainment\":\"kindergarten\",\"is_pwd_minor\":false,\"pwd_type_of_disability\":null}', 'http://127.0.0.1:8000/admin/children-records/6', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-23 04:51:44', '2025-11-23 04:51:44'),
(84, 'App\\Models\\User', 1, 'restored', 'App\\Models\\Minor', 2, '[]', '{\"id\":2,\"application_type\":\"new_applicant\",\"date_applied\":\"2025-07-08\",\"minor_last_name\":\"bautista\",\"minor_first_name\":\"aida\",\"minor_middle_name\":\"olivo\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2025-02-12\",\"minor_birthplace\":\"Urdaneta City\",\"minor_age\":4,\"minor_sex\":\"female\",\"minor_civil_status\":\"single\",\"minor_religion\":\"Roman Catholic\",\"minor_house_no_street\":\"Bani Pangasinan\",\"minor_barangay\":\"GUISET NORTE\",\"minor_municipality_city\":\"Bani\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"1\",\"guardian_landline_no\":null,\"guardian_mobile_no\":\"+639506440263\",\"guardian_email_address\":\"bautista.noly16@gmail.com\",\"minor_educational_attainment\":\"none\",\"minor_other_educational_attainment\":null,\"daycare_center\":\"Bactad East CDC\",\"father_last_name\":\"BAUTISTA\",\"father_first_name\":\"NOLY\",\"father_middle_name\":\"CASTRO\",\"mother_last_name\":\"BAUTISTA\",\"mother_first_name\":\"NOLY\",\"mother_middle_name\":\"OLIVO\",\"guardian_last_name\":\"BAUTISTA\",\"guardian_first_name\":\"NOLY\",\"guardian_middle_name\":\"OLIVO\",\"is_pwd_minor\":1,\"pwd_registration_status\":\"first_time\",\"pwd_number\":null,\"pwd_type_of_disability\":\"[\\\"deaf_or_hard_of_hearing\\\"]\",\"pwd_cause_of_disability\":\"[\\\"down_syndrome\\\"]\",\"pwd_other_disability_cause\":null,\"is_daycare_student\":1,\"is_archived\":1,\"daycare_actual_weight_date\":\"2025-07-08\",\"daycare_weight_kg\":\"34.00\",\"daycare_height_cm\":\"34.00\",\"daycare_weight_for_age\":\"N\\/A\",\"daycare_height_for_age\":\"N\\/A\",\"daycare_weight_for_height\":\"N\\/A\",\"accomplished_by\":\"applicant\",\"representative_name\":null,\"license_no\":null,\"processing_officer_last_name\":null,\"processing_officer_first_name\":null,\"processing_officer_middle_name\":null,\"approving_officer_last_name\":null,\"approving_officer_first_name\":null,\"approving_officer_middle_name\":null,\"encoder_last_name\":null,\"encoder_first_name\":null,\"encoder_middle_name\":null,\"name_of_reporting_unit\":\"asdasd\",\"control_no\":\"asdas\",\"doctor_last_name\":null,\"doctor_first_name\":null,\"doctor_middle_name\":null,\"license_no_physician\":null}', 'http://127.0.0.1:8000/admin/archived-records/17/restore', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-24 02:37:16', '2025-11-24 02:37:16'),
(85, 'App\\Models\\User', 1, 'deleted', 'App\\Models\\Minor', 2, '{\"id\":2,\"application_type\":\"new_applicant\",\"date_applied\":\"2025-07-08\",\"minor_last_name\":\"bautista\",\"minor_first_name\":\"aida\",\"minor_middle_name\":\"olivo\",\"minor_suffix\":null,\"minor_date_of_birth\":\"2025-02-12\",\"minor_birthplace\":\"Urdaneta City\",\"minor_age\":4,\"minor_sex\":\"female\",\"minor_civil_status\":\"single\",\"minor_religion\":\"Roman Catholic\",\"minor_house_no_street\":\"Bani Pangasinan\",\"minor_barangay\":\"GUISET NORTE\",\"minor_municipality_city\":\"Bani\",\"minor_province\":\"Pangasinan\",\"minor_region\":\"1\",\"guardian_landline_no\":null,\"guardian_mobile_no\":\"+639506440263\",\"guardian_email_address\":\"bautista.noly16@gmail.com\",\"minor_educational_attainment\":\"none\",\"minor_other_educational_attainment\":null,\"daycare_center\":\"Bactad East CDC\",\"father_last_name\":\"BAUTISTA\",\"father_first_name\":\"NOLY\",\"father_middle_name\":\"CASTRO\",\"mother_last_name\":\"BAUTISTA\",\"mother_first_name\":\"NOLY\",\"mother_middle_name\":\"OLIVO\",\"guardian_last_name\":\"BAUTISTA\",\"guardian_first_name\":\"NOLY\",\"guardian_middle_name\":\"OLIVO\",\"is_pwd_minor\":1,\"pwd_registration_status\":\"first_time\",\"pwd_number\":null,\"pwd_type_of_disability\":\"[\\\"deaf_or_hard_of_hearing\\\"]\",\"pwd_cause_of_disability\":\"[\\\"down_syndrome\\\"]\",\"pwd_other_disability_cause\":null,\"is_daycare_student\":1,\"is_archived\":1,\"daycare_actual_weight_date\":\"2025-07-08\",\"daycare_weight_kg\":\"34.00\",\"daycare_height_cm\":\"34.00\",\"daycare_weight_for_age\":\"N\\/A\",\"daycare_height_for_age\":\"N\\/A\",\"daycare_weight_for_height\":\"N\\/A\",\"accomplished_by\":\"applicant\",\"representative_name\":null,\"license_no\":null,\"processing_officer_last_name\":null,\"processing_officer_first_name\":null,\"processing_officer_middle_name\":null,\"approving_officer_last_name\":null,\"approving_officer_first_name\":null,\"approving_officer_middle_name\":null,\"encoder_last_name\":null,\"encoder_first_name\":null,\"encoder_middle_name\":null,\"name_of_reporting_unit\":\"asdasd\",\"control_no\":\"asdas\",\"doctor_last_name\":null,\"doctor_first_name\":null,\"doctor_middle_name\":null,\"license_no_physician\":null}', '[]', 'http://127.0.0.1:8000/admin/children-records/2/archive', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-24 02:37:24', '2025-11-24 02:37:24'),
(86, 'App\\Models\\User', 1, 'created', 'App\\Models\\Task', 7, '[]', '{\"task_title\":\"Master List\",\"task_description\":\"Finish the master list\",\"date_created\":\"2025-11-26 00:00:00\",\"due_date\":\"2025-11-30 00:00:00\",\"status\":\"active\",\"id\":7}', 'http://127.0.0.1:8000/admin/tasks', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', NULL, '2025-11-25 20:32:49', '2025-11-25 20:32:49');

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(10, '0001_01_01_000000_create_users_table', 1),
(11, '0001_01_01_000001_create_cache_table', 1),
(12, '0001_01_01_000002_create_jobs_table', 1),
(13, '2025_06_25_142848_create_minors_table', 1),
(14, '2025_06_29_104559_create_pwd_minors_table', 1),
(15, '2025_07_01_215427_add_role_and_daycare_center_to_users_table', 1),
(16, '2025_07_03_110628_create_who_growth_data_table', 1),
(17, '2025_07_03_202705_create_aids_table', 1),
(18, '2025_07_03_221417_create_announcements_table', 1),
(19, '2025_07_06_202632_create_aid_assistances_table', 2),
(20, '2025_07_07_083827_add_soft_deletes_to_minors_table', 3),
(21, '2025_07_17_004503_create_tasks_table', 4),
(22, '2025_07_18_111659_add_is_archived_to_minors_table', 5),
(23, '2025_07_25_152947_create_archived_records_table', 6),
(24, '2025_08_06_153213_add_status_to_tasks_table', 7),
(25, '2025_08_06_171347_add_status_to_tasks_table', 8),
(26, '2025_08_07_133121_add_due_date_to_announcements_table', 9),
(27, '2025_08_07_211948_add_soft_deletes_to_announcements_table', 10),
(28, '2025_08_07_221744_create_audits_table', 11),
(29, '2025_08_10_142343_add_approval_status_to_minors_table', 12),
(30, '2025_08_10_161551_remove_approval_status_from_minors_table', 13),
(31, '2025_08_10_161712_create_pending_minor_applications_table', 14),
(32, '2025_10_26_233154_create_password_reset_tokens_table', 15);

-- --------------------------------------------------------

--
-- Table structure for table `minors`
--

CREATE TABLE `minors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `application_type` varchar(255) NOT NULL,
  `date_applied` date NOT NULL,
  `minor_last_name` varchar(255) NOT NULL,
  `minor_first_name` varchar(255) NOT NULL,
  `minor_middle_name` varchar(255) DEFAULT NULL,
  `minor_suffix` varchar(255) DEFAULT NULL,
  `minor_date_of_birth` date NOT NULL,
  `minor_birthplace` varchar(255) DEFAULT NULL,
  `minor_age` int(11) NOT NULL,
  `minor_sex` varchar(255) NOT NULL,
  `minor_civil_status` varchar(255) NOT NULL,
  `minor_religion` varchar(255) DEFAULT NULL,
  `minor_house_no_street` varchar(255) NOT NULL,
  `minor_barangay` varchar(255) NOT NULL,
  `minor_municipality_city` varchar(255) NOT NULL,
  `minor_province` varchar(255) NOT NULL,
  `minor_region` varchar(255) NOT NULL,
  `guardian_landline_no` varchar(255) DEFAULT NULL,
  `guardian_mobile_no` varchar(255) DEFAULT NULL,
  `guardian_email_address` varchar(255) DEFAULT NULL,
  `minor_educational_attainment` varchar(255) NOT NULL,
  `minor_other_educational_attainment` varchar(255) DEFAULT NULL,
  `daycare_center` varchar(255) DEFAULT NULL,
  `father_last_name` varchar(255) DEFAULT NULL,
  `father_first_name` varchar(255) DEFAULT NULL,
  `father_middle_name` varchar(255) DEFAULT NULL,
  `mother_last_name` varchar(255) DEFAULT NULL,
  `mother_first_name` varchar(255) DEFAULT NULL,
  `mother_middle_name` varchar(255) DEFAULT NULL,
  `guardian_last_name` varchar(255) DEFAULT NULL,
  `guardian_first_name` varchar(255) DEFAULT NULL,
  `guardian_middle_name` varchar(255) DEFAULT NULL,
  `is_pwd_minor` tinyint(1) NOT NULL DEFAULT 0,
  `pwd_registration_status` varchar(255) DEFAULT NULL,
  `pwd_number` varchar(255) DEFAULT NULL,
  `pwd_type_of_disability` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`pwd_type_of_disability`)),
  `pwd_cause_of_disability` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`pwd_cause_of_disability`)),
  `pwd_other_disability_cause` varchar(255) DEFAULT NULL,
  `is_daycare_student` tinyint(1) NOT NULL DEFAULT 0,
  `is_archived` tinyint(1) NOT NULL DEFAULT 0,
  `daycare_actual_weight_date` date DEFAULT NULL,
  `daycare_weight_kg` decimal(8,2) DEFAULT NULL,
  `daycare_height_cm` decimal(8,2) DEFAULT NULL,
  `daycare_weight_for_age` varchar(255) DEFAULT NULL,
  `daycare_height_for_age` varchar(255) DEFAULT NULL,
  `daycare_weight_for_height` varchar(255) DEFAULT NULL,
  `accomplished_by` varchar(255) NOT NULL,
  `representative_name` varchar(255) DEFAULT NULL,
  `license_no` varchar(255) DEFAULT NULL,
  `processing_officer_last_name` varchar(255) DEFAULT NULL,
  `processing_officer_first_name` varchar(255) DEFAULT NULL,
  `processing_officer_middle_name` varchar(255) DEFAULT NULL,
  `approving_officer_last_name` varchar(255) DEFAULT NULL,
  `approving_officer_first_name` varchar(255) DEFAULT NULL,
  `approving_officer_middle_name` varchar(255) DEFAULT NULL,
  `encoder_last_name` varchar(255) DEFAULT NULL,
  `encoder_first_name` varchar(255) DEFAULT NULL,
  `encoder_middle_name` varchar(255) DEFAULT NULL,
  `name_of_reporting_unit` varchar(255) DEFAULT NULL,
  `control_no` varchar(255) DEFAULT NULL,
  `doctor_last_name` varchar(255) DEFAULT NULL,
  `doctor_first_name` varchar(255) DEFAULT NULL,
  `doctor_middle_name` varchar(255) DEFAULT NULL,
  `license_no_physician` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `minors`
--

INSERT INTO `minors` (`id`, `application_type`, `date_applied`, `minor_last_name`, `minor_first_name`, `minor_middle_name`, `minor_suffix`, `minor_date_of_birth`, `minor_birthplace`, `minor_age`, `minor_sex`, `minor_civil_status`, `minor_religion`, `minor_house_no_street`, `minor_barangay`, `minor_municipality_city`, `minor_province`, `minor_region`, `guardian_landline_no`, `guardian_mobile_no`, `guardian_email_address`, `minor_educational_attainment`, `minor_other_educational_attainment`, `daycare_center`, `father_last_name`, `father_first_name`, `father_middle_name`, `mother_last_name`, `mother_first_name`, `mother_middle_name`, `guardian_last_name`, `guardian_first_name`, `guardian_middle_name`, `is_pwd_minor`, `pwd_registration_status`, `pwd_number`, `pwd_type_of_disability`, `pwd_cause_of_disability`, `pwd_other_disability_cause`, `is_daycare_student`, `is_archived`, `daycare_actual_weight_date`, `daycare_weight_kg`, `daycare_height_cm`, `daycare_weight_for_age`, `daycare_height_for_age`, `daycare_weight_for_height`, `accomplished_by`, `representative_name`, `license_no`, `processing_officer_last_name`, `processing_officer_first_name`, `processing_officer_middle_name`, `approving_officer_last_name`, `approving_officer_first_name`, `approving_officer_middle_name`, `encoder_last_name`, `encoder_first_name`, `encoder_middle_name`, `name_of_reporting_unit`, `control_no`, `doctor_last_name`, `doctor_first_name`, `doctor_middle_name`, `license_no_physician`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 'new_applicant', '2025-07-08', 'bautista', 'aida', 'olivo', NULL, '2025-02-12', 'Urdaneta City', 4, 'female', 'single', 'Roman Catholic', 'Bani Pangasinan', 'GUISET NORTE', 'Bani', 'Pangasinan', '1', NULL, '+639506440263', 'bautista.noly16@gmail.com', 'none', NULL, 'Bactad East CDC', 'BAUTISTA', 'NOLY', 'CASTRO', 'BAUTISTA', 'NOLY', 'OLIVO', 'BAUTISTA', 'NOLY', 'OLIVO', 1, 'first_time', NULL, '[\"deaf_or_hard_of_hearing\"]', '[\"down_syndrome\"]', NULL, 1, 1, '2025-07-08', 34.00, 34.00, 'N/A', 'N/A', 'N/A', 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'asdasd', 'asdas', NULL, NULL, NULL, NULL, '2025-07-07 15:41:04', '2025-11-24 02:37:24', '2025-11-24 02:37:24'),
(3, 'new_applicant', '2025-01-09', 'sagaoinit', 'julius', 'bravo', NULL, '2025-04-25', 'Urdaneta City', 2, 'female', 'single', 'Roman Catholic', 'Bani Pangasinan', 'GUISET NORTE', 'Bani', 'Pangasinan', '1', NULL, '+639506440263', 'bautista.noly16@gmail.com', 'none', NULL, 'Bactad East CDC', 'BAUTISTA', 'NOLY', 'CASTRO', 'BAUTISTA', 'NOLY', NULL, 'BAUTISTA', 'NOLY', 'OLIVO', 1, 'first_time', NULL, '[\"mental_disability\"]', NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'zagfedghyedg', 'adgfadg', NULL, NULL, NULL, NULL, '2025-07-08 05:16:09', '2025-07-24 03:26:16', '2025-07-24 03:26:16'),
(4, 'new_applicant', '2024-11-07', 'BAUTISTA', 'NOLY', 'OLIVO', NULL, '2025-01-10', 'Urdaneta City', 5, 'female', 'single', 'Roman Catholic', 'Bani Pangasinan', 'bantog', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', NULL, '+639506440263', 'bautista.noly16@gmail.com', 'none', NULL, 'Bactad East CDC', 'BAUTISTA', 'NOLY', 'CASTRO', 'BAUTISTA', 'NOLY', 'OLIVO', 'BAUTISTA', 'NOLY', 'OLIVO', 1, 'first_time', NULL, '[\"intellectual_disability\"]', '[\"acquired\"]', NULL, 1, 0, '2025-07-09', 34.00, 34.00, 'N/A', 'N/A', 'N/A', 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'asdasdad', 'adasda', NULL, NULL, NULL, NULL, '2025-07-08 15:18:06', '2025-08-17 06:55:05', '2025-08-17 06:55:05'),
(5, 'new_applicant', '2025-03-03', 'sdasdas', 'dsadasdasd', 'adasdasdasd', NULL, '2024-12-05', 'Urdaneta City', 7, 'female', 'single', 'Roman Catholic', 'sdasdasd', 'san_miguel', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', NULL, '+639506440263', 'bautista.noly16@gmail.com', 'vocational', NULL, 'Bactad East CDC', 'BAUTISTA', 'NOLY', 'sdadasdsds', 'BAUTISTA', 'NOLY', 'dasdssdasd', 'BAUTISTA', 'NOLY', 'dsdsadsadas', 1, 'first_time', NULL, '[\"mental_disability\"]', '[\"congenital_inborn\"]', NULL, 1, 0, '2025-07-09', 23.00, 45.00, 'N/A', 'N/A', 'N/A', 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'asd', 'dfsdf', NULL, NULL, NULL, NULL, '2025-07-08 17:21:55', '2025-11-16 11:11:53', '2025-11-16 11:11:53'),
(6, 'birth_registration', '2025-11-23', 'Pilorin', 'Vanessa', 'Bautista', NULL, '2021-10-21', 'Urdaneta City', 44, 'female', 'single', 'Roman Catholic', 'Santol Street', 'anonas', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', NULL, '+639506440263', 'bautista.noly16@gmail.com', 'kindergarten', NULL, 'Bactad East CDC', 'BAUTISTA', 'NOLY', 'fdhdfh', 'BAUTISTA', 'NOLY', 'dfhgdfh', 'BAUTISTA', 'NOLY', 'fdhd', 0, 'first_time', NULL, NULL, '[\"acquired\"]', NULL, 1, 0, '2025-07-17', 14.00, 88.00, 'Normal Weight', 'Stunted', 'Obese', 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'dfhdfh', 'dfhdfh', NULL, NULL, NULL, NULL, '2025-07-09 18:18:40', '2025-11-23 04:51:44', NULL),
(7, 'new_applicant', '2025-07-14', 'ahgkgkhj', 'klhjglghl', 'ghkgfhk', NULL, '2024-07-12', 'Urdaneta City', 12, 'male', 'single', 'Roman Catholic', '34 sampaloc street', 'San Miguel', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', NULL, '8968796789769', 'bautista.noly16@gmail.com', 'none', NULL, 'Bactad East CDC', 'hkhjgk', 'kfgh', 'fgkgfhk', 'fgkfgkhf', 'gfhkgfkgfk', 'gfhk', 'gkfgkfg', 'kgfkgfk', 'fghkfgkfg', 1, 'first_time', NULL, '\"[\\\"mental_disability\\\"]\"', '\"[\\\"cerebral_palsy\\\"]\"', NULL, 1, 0, '2025-07-14', 12.00, 60.00, 'Possible Risk of Overweight', 'Severely Stunted', 'Severely Obese', 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'tertert', 'ertertg', NULL, NULL, NULL, NULL, '2025-07-13 17:02:53', '2025-11-23 02:21:36', NULL),
(8, 'new_applicant', '2025-07-21', 'true', 'true', 'true', NULL, '2025-07-10', 'Urdaneta City', 0, 'female', 'separated', 'Roman Catholic', '33', 'san_miguel', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', NULL, '09506440263', 'bautista.noly16@gmail.com', 'senior_high_school', NULL, 'Bactad East CDC', 'true', 'true', 'true', 'true', 'true', 'true', 'true', 'true', 'true', 1, 'first_time', NULL, '\"[\\\"deaf_or_hard_of_hearing\\\"]\"', '\"[\\\"maternal_infection\\\"]\"', NULL, 1, 0, '2025-07-21', 11.00, 67.00, 'Possible Risk of Overweight', 'Normal Height', 'Severely Obese', 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'true', 'true', NULL, NULL, NULL, 'true', '2025-07-20 18:41:56', '2025-07-30 15:48:09', '2025-07-30 15:48:09'),
(9, 'new_applicant', '2025-07-21', 'please', 'please', 'please', NULL, '2022-07-21', 'Urdaneta City', 36, 'female', 'single', 'Roman Catholic', '44', 'san_miguel', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', NULL, NULL, NULL, 'vocational', NULL, 'Bactad East CDC', 'please', 'please', 'please', 'please', 'please', 'please', 'please', 'please', 'please', 0, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-07-21 03:02:43', '2025-07-24 03:18:15', '2025-07-24 03:18:15'),
(10, 'new_applicant', '2025-07-25', 'design', 'design', 'design', NULL, '2022-07-25', 'Urdaneta City', 36, 'female', 'single', 'Roman Catholic', '33', 'bayaoas', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', NULL, '09506440263', 'bautistaoly16@gmail.com', 'none', NULL, 'Bactad East CDC', 'design', 'design', 'design', 'design', 'design', 'design', 'design', 'design', 'design', 0, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(11, 'new_applicant', '2025-07-22', 'Untalan', 'cristine', 'fortes', NULL, '2020-09-18', 'Urdaneta City', 58, 'female', 'single', 'Roman Catholic', 'zone 2', 'bantog', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', '08290479863', '7896785754645', 'angelicauntalan26@gmail.com', 'kindergarten', NULL, 'Bactad East CDC', 'untalan', 'carlito', 'cordova', 'untalan', 'emy rose', 'fortes', 'untalan', 'amy', 'cordova', 0, NULL, NULL, NULL, NULL, NULL, 1, 0, '2025-07-22', 17.90, 107.90, 'Possible Risk of Overweight', 'Normal Height', 'Normal Weight-for-Height', 'guardian', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-07-21 09:24:13', '2025-08-10 07:18:48', NULL),
(12, 'new_applicant', '2025-07-22', 'Untalan', 'cristine', 'fortes', NULL, '2020-09-18', 'Urdaneta City', 58, 'female', 'single', 'Roman Catholic', 'zone 2', 'bantog', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', '08290479863', '7896785754645', 'angelicauntalan26@gmail.com', 'kindergarten', NULL, 'Bactad East CDC', 'untalan', 'carlito', 'cordova', 'untalan', 'emy rose', 'fortes', 'untalan', 'amy', 'cordova', 0, NULL, NULL, NULL, NULL, NULL, 1, 0, '2025-07-22', 17.90, 107.90, 'Possible Risk of Overweight', 'Normal Height', 'Normal Weight-for-Height', 'guardian', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-07-21 09:24:16', '2025-08-10 07:18:47', NULL),
(13, 'new_applicant', '2025-07-22', 'botacion', 'mac mac', 'untalan', NULL, '2020-05-12', 'Urdaneta City', 62, 'male', 'single', 'Roman Catholic', 'zone 1', 'anonang', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', '09477465435', '34537469', 'angelicauntalan26@gmail.com', 'kindergarten', NULL, 'Bactad East CDC', 'botacion', 'jomar', 'B', 'untalan', 'susan', 'cordova', 'untalan', 'susan', 'cordova', 0, NULL, NULL, NULL, NULL, NULL, 1, 1, '2025-07-22', 17.90, 107.90, 'N/A (>5 years)', 'N/A (>5 years)', 'N/A (>5 years)', 'guardian', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-07-21 09:31:18', '2025-08-17 07:10:22', NULL),
(14, 'new_applicant', '2025-06-10', 'untalan', 'john marck', 'fortes', NULL, '2020-01-26', 'Urdaneta City', 65, 'male', 'single', 'Roman Catholic', 'zone 2', 'san_antonio', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', '09477465435', '34537469', 'angelicauntalan26@gmail.com', 'kindergarten', NULL, 'Bactad East CDC', 'untalan', 'carlito', 'cordova', 'untalan', 'emy rose', 'fortes', 'untalan', 'amy', 'cordova', 0, NULL, NULL, NULL, NULL, NULL, 1, 0, '2025-07-22', 15.40, 94.00, 'N/A (>5 years)', 'N/A (>5 years)', 'N/A (>5 years)', 'guardian', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-07-21 09:40:07', '2025-08-10 07:58:33', NULL),
(15, 'new_applicant', '2025-05-07', 'rosendo', 'john alexis', 'r', NULL, '2021-06-04', 'Urdaneta City', 49, 'male', 'single', 'Roman Catholic', 'zone 2', 'san_jose', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', '02838363763', '09167389276', 'jocelyn@gmail.com', 'kindergarten', NULL, 'Bactad East CDC', 'rosendo', 'jose', 'm', 'rosendo', 'jocelyn', 'u.', 'untalan', 'jocelyn', 'u.', 0, NULL, NULL, NULL, NULL, NULL, 1, 0, '2025-07-23', 15.00, 37.50, 'Normal Weight', 'Severely Stunted', 'Severely Obese', 'guardian', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-07-22 09:54:23', '2025-09-16 14:02:34', '2025-09-16 14:02:34'),
(16, 'new_applicant', '2025-05-07', 'rosendo', 'john alexis', 'r', NULL, '2021-06-04', 'Urdaneta City', 49, 'male', 'single', 'Roman Catholic', 'zone 2', 'san_jose', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', '02838363763', '09167389276', 'jocelyn@gmail.com', 'kindergarten', NULL, 'Bactad East CDC', 'rosendo', 'jose', 'm', 'rosendo', 'jocelyn', 'u.', 'untalan', 'jocelyn', 'u.', 0, NULL, NULL, NULL, NULL, NULL, 1, 0, '2025-07-23', 15.00, 37.50, 'Normal Weight', 'Severely Stunted', 'Severely Obese', 'guardian', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-07-22 09:54:25', '2025-08-10 07:18:46', NULL),
(17, 'new_applicant', '2025-07-23', 'villanueva', 'roland', 'n', NULL, '2020-12-24', 'Urdaneta City', 54, 'male', 'single', 'Roman Catholic', 'zone2', 'poblacion', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', '0937546222', '09753652236', 'maricar12@gmail.com', 'kindergarten', NULL, 'Bactad East CDC', 'villanueva', 'royland', 'k', 'villanueva', 'maricar', 'n', 'villanueva', 'maricar', 'n', 0, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'guardian', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-07-22 09:58:49', '2025-08-10 07:18:45', NULL),
(18, 'new_applicant', '2025-06-16', 'catchin', 'aldrin', 'g.', NULL, '2020-12-23', 'Urdaneta City', 55, 'male', 'single', 'Roman Catholic', 'zone4', 'san_antonio', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', '02976652113', '09562861226', 'susana45@gmail.com', 'none', NULL, 'Bactad East CDC', 'catchin', 'alfred', 'd', 'catchin', 'susana', 'g.', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 1, 0, '2025-06-16', 18.70, 109.90, 'Possible Risk of Overweight', 'Normal Height', 'Normal Weight-for-Height', 'guardian', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-07-22 10:16:20', '2025-08-10 07:18:45', NULL),
(19, 'new_applicant', '2025-04-07', 'lewis', 'althea', 'untalan', NULL, '2021-08-05', 'Urdaneta City', 47, 'female', 'single', 'Roman Catholic', 'zone 2', 'bayaoas', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', '0936366743', '09127937633', 'amyuntalan123@gmail.com', 'none', NULL, 'Bactad East CDC', 'lewis', 'bradley', 'j', 'untalan', 'amy', 'u', 'untalan', 'amy', 'u.', 0, NULL, NULL, NULL, NULL, NULL, 1, 0, '2025-04-07', 16.00, 101.60, 'Normal Weight', 'Normal Height', 'Normal Weight-for-Height', 'guardian', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-07-26 21:54:54', '2025-08-10 07:18:44', NULL),
(20, 'new_applicant', '2025-02-10', 'daus', 'jayden', 'h.', NULL, '2021-12-22', 'Urdaneta City', 43, 'male', 'single', 'Roman Catholic', 'zone 3', 'baket_baket', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', '01946478134', '01843243264', NULL, 'none', NULL, 'Bactad East CDC', 'daus', 'andres', 'l', 'daus', 'hershy', 'h', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 1, 0, '2025-02-10', 16.70, 102.90, 'Possible Risk of Overweight', 'Normal Height', 'Overweight', 'guardian', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-07-26 21:58:25', '2025-11-22 03:25:24', NULL),
(21, 'new_applicant', '2025-05-16', 'cerezo', 'brian', 'u.', NULL, '2021-09-15', 'Urdaneta City', 46, 'male', 'single', 'Roman Catholic', 'zone1', 'san_juan', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', '0927263424', '09123456779', 'charitocerezo@gmail.com', 'none', NULL, 'Bactad East CDC', 'cerezo', 'roberto', 'c.', 'cerezo', 'charito', 'u.', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 1, 0, '2025-05-16', 16.80, 103.80, 'Normal Weight', 'Normal Height', 'Overweight', 'guardian', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-07-26 22:01:49', '2025-08-10 07:18:43', NULL),
(22, 'new_applicant', '2025-12-28', 'bain', 'princess', 'k', NULL, '2021-12-12', 'Urdaneta City', 43, 'female', 'single', 'Roman Catholic', 'zone3', 'pugaro', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', '0938631534', '0982766354', 'bain1456@gmail.com', 'none', NULL, 'Bactad East CDC', 'bain', 'leo', 'p', 'bain', 'maylyn', 'k', 'bain', 'maylyn', 'k', 0, NULL, NULL, NULL, NULL, NULL, 1, 0, '2025-12-28', 17.00, 100.50, 'Possible Risk of Overweight', 'Normal Height', 'Overweight', 'guardian', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-07-26 22:04:45', '2025-08-10 07:18:43', NULL),
(23, 'new_applicant', '2025-01-23', 'aguirre', 'mayjoy', 'f', NULL, '2021-04-26', 'Urdaneta City', 51, 'female', 'single', 'Roman Catholic', 'zone 2', 'pinmaludpod', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', '09172362313', '0926356125', 'aguirrelyka@gmail.com', 'none', NULL, 'Bactad East CDC', 'aguirre', 'pedro', 'k', 'aguirre', 'lyka', 'f', 'aguirre', 'lyka', 'f', 0, NULL, NULL, NULL, NULL, NULL, 1, 0, '2025-01-23', 15.50, 101.00, 'Normal Weight', 'Normal Height', 'Normal Weight-for-Height', 'guardian', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-07-26 22:13:17', '2025-08-17 06:43:35', NULL),
(24, 'new_applicant', '2025-08-10', 'test1', 'test1', 'test1', NULL, '2022-08-10', 'Urdaneta City', 36, 'male', 'single', 'Roman Catholic', '33', 'san_juan', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', '5465', '6564356346', 'test1@gmail.com', 'none', NULL, 'Bactad East CDC', 'test1', 'test1', 'test1', 'test1', 'test1', 'test1', 'test1', 'test1', 'test1', 0, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-08-10 07:55:02', '2025-08-10 07:58:35', NULL),
(25, 'new_applicant', '2025-08-11', 'test15', 'test15', 'test15', NULL, '2022-08-11', 'Urdaneta City', 36, 'male', 'single', 'Roman Catholic', '77', 'san_jose', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', '09876', '34653654765', 'test15@gmail.com', 'none', NULL, 'Bactad East CDC', 'test15', 'test15test15', 'test15', 'test15', 'test15', 'test15', 'test15', 'test15', 'test15', 1, NULL, NULL, '[]', '[]', NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-08-10 19:22:58', '2025-08-14 19:13:27', NULL),
(26, 'new_applicant', '2025-09-16', 'sison', 'prince', 'sison', NULL, '2022-09-16', 'Urdaneta City', 36, 'female', 'single', 'Roman Catholic', '33 sampaloc', 'bantog', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', 'N/A', '095045634876', 'sison@gmail.com', 'kindergarten', NULL, 'Bactad East CDC', 'sison', 'sison', 'sison', 'sison', 'sison', 'sison', 'sison', 'sison', 'sison', 0, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-09-16 05:40:59', '2025-09-16 05:40:59', NULL),
(27, 'new_applicant', '2025-10-05', 'bautista', 'napoleon', 'lap', NULL, '2021-10-05', 'Urdaneta City', 4, 'male', 'single', 'Roman Catholic', 'sampaloc', 'san_vicente', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', NULL, '09506440269', 'kill@gmail.com', 'kindergarten', NULL, 'Bactad East CDC', 'BAUTISTA', 'NOLY', 'CASTRO', 'BAUTISTA', 'NOLY', 'CASTRO', 'BAUTISTA', 'NOLY', 'CASTRO', 0, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-05 15:14:12', '2025-10-13 14:36:56', NULL),
(28, 'new_applicant', '2025-10-14', 'bautista', 'lord', 'lapidez', NULL, '2021-10-14', 'Urdaneta City', 48, 'male', 'single', 'Roman Catholic', '45 sampaloc', 'bantog', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', 'N/A', '09509505902', 'lord@gmail.com', 'kindergarten', NULL, 'Bactad East CDC', 'bautista', 'nap', 'castro', 'bautista', 'benje', 'lapidez', 'bautista', 'nap', 'castro', 0, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-14 13:51:54', '2025-10-14 13:51:54', NULL),
(29, 'new_applicant', '2025-10-16', 'bautista', 'Eleiza Mae', 'falcasantos', 'N/A', '2022-10-16', 'Urdaneta City', 36, 'male', 'single', 'Roman Catholic', '12 mago', 'bantog', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', 'N/A', '09506440263', 'bautista.noly16@gmail.com', 'kindergarten', NULL, 'Bactad East CDC', 'BAUTISTA', 'NOLY', 'CASTRO', 'BAUTISTA', 'NOLY', 'OLIVO', 'BAUTISTA', 'NOLY', 'OLIVO', 0, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-16 13:45:57', '2025-10-16 13:45:57', NULL),
(30, 'new_applicant', '2025-10-22', 'pilorin', 'warren', 'bautista', NULL, '2022-10-22', 'Urdaneta City', 36, 'male', 'single', 'Roman Catholic', '49 santol', 'anonang', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', NULL, '09506440263', 'bautista.noly16@gmail.com', 'kindergarten', NULL, 'Bactad East CDC', 'BAUTISTA', 'NOLY', 'CASTRO', 'BAUTISTA', 'NOLY', 'OLIVO', 'BAUTISTA', 'NOLY', 'OLIVO', 0, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-21 18:52:13', '2025-10-21 18:52:13', NULL),
(31, 'new_applicant', '2025-10-22', 'pilorin', 'vanessa', 'bautista', NULL, '2020-10-22', 'Urdaneta City', 60, 'female', 'single', 'Roman Catholic', '22 sampaoc', 'bacag', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', NULL, '09506440263', 'bautista.noly16@gmail.com', 'none', NULL, 'Bactad East CDC', 'BAUTISTA', 'NOLY', 'CASTRO', 'BAUTISTA', 'NOLY', 'OLIVO', 'BAUTISTA', 'NOLY', 'OLIVO', 0, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-21 18:58:38', '2025-10-21 18:58:38', NULL),
(32, 'new_applicant', '2025-10-26', 'bautista', 'banjo', 'olivo', NULL, '2022-10-26', 'Urdaneta City', 36, 'male', 'single', 'Roman Catholic', '53 sampaloc', 'bantog', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', 'N/A', '09506440265', 'bautistanoly16@gmail.com', 'kindergarten', NULL, 'Bactad East CDC', 'BAUTISTA', 'NOLY', 'castro', 'BAUTISTA', 'adelaida', 'olivo', 'BAUTISTA', 'adelaida', 'olivo', 1, NULL, NULL, '\"[\\\"speech_and_language_impairment\\\"]\"', '\"[\\\"heredity\\\"]\"', NULL, 1, 0, '2025-10-26', 15.00, 87.00, 'Normal Weight', 'Normal Height', 'Severely Obese', 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'NOLY BAUTISTA', '56456', NULL, NULL, NULL, '23435', '2025-10-26 08:10:29', '2025-10-26 08:10:29', NULL),
(33, 'new_applicant', '2025-10-26', 'bautista', 'benje', 'olivo', NULL, '2022-10-26', 'Urdaneta City', 36, 'female', 'single', 'Roman Catholic', '37 santol', 'bantog', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', NULL, '09506440262', 'bautistanoly16@gmail.com', 'kindergarten', NULL, 'Bactad East CDC', 'BAUTISTA', 'NOLY', 'castro', 'BAUTISTA', 'NOLY', 'olivo', 'BAUTISTA', 'NOLY', 'olivo', 1, NULL, NULL, '\"[\\\"deaf_or_hard_of_hearing\\\"]\"', '\"[\\\"heredity\\\"]\"', NULL, 1, 0, '2025-10-26', 14.00, 87.00, 'Normal Weight', 'Normal Height', 'Overweight', 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'NOLY BAUTISTA', '09089993618', NULL, NULL, NULL, '23435', '2025-10-26 08:46:30', '2025-10-26 08:46:30', NULL),
(34, 'new_applicant', '2025-10-26', 'Delacruz', 'lynette', 'Santos', NULL, '2021-07-19', 'Urdaneta City', 51, 'female', 'single', 'Roman Catholic', '33 Samapaloc', 'bantog', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', NULL, '09090909090', 'xtraspicyhotfinesytmaria@gmail.com', 'kindergarten', NULL, 'Bactad East CDC', 'Delacruz', 'Pedring', 'penduco', 'Santos', 'Maria', 'Galang', 'Santos', 'Maria', 'Galang', 1, NULL, NULL, '\"[\\\"intellectual_disability\\\"]\"', '\"[\\\"heredity\\\"]\"', NULL, 1, 0, '2025-10-26', 15.00, 87.00, 'Normal Weight', 'Stunted', 'Obese', 'guardian', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'BANJO', '09089993618', NULL, NULL, NULL, 'true', '2025-10-26 10:46:27', '2025-10-26 10:46:27', NULL),
(35, 'new_applicant', '2025-11-10', 'sison', 'kyle', 'ostrad', NULL, '2022-11-10', 'Urdaneta City', 36, 'male', 'single', 'Roman Catholic', '24 mapel street', 'bantog', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', NULL, '09783487374', NULL, 'daycare', NULL, 'Bactad East CDC', 'sison', 'juan', 'tawan', 'sison', 'lisa', 'santos', 'sison', 'lisa', 'santos', 0, NULL, NULL, NULL, NULL, NULL, 1, 0, '2025-11-10', 45.00, 76.00, 'Possible Risk of Overweight', 'Severely Stunted', 'Severely Obese', 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-11-10 06:09:43', '2025-11-10 06:09:43', NULL),
(36, 'new_applicant', '2025-11-10', 'amber', 'young', 'walker', NULL, '2022-11-10', 'Urdaneta City', 36, 'male', 'single', 'Roman Catholic', '34 peek street', 'bacag', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', NULL, '09657575675', NULL, 'daycare', NULL, 'Bactad East CDC', 'amber', 'papi', 'tran', 'amber', 'mami', 'tren', 'amber', 'mami', 'walker', 0, NULL, NULL, NULL, NULL, NULL, 1, 0, '2025-11-10', 65.00, 78.00, 'Possible Risk of Overweight', 'Severely Stunted', 'Severely Obese', 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-11-10 06:35:57', '2025-11-10 06:35:57', NULL),
(37, 'new_applicant', '2025-11-10', 'walker', 'kisha', 'ramos', NULL, '2021-11-10', 'Urdaneta City', 48, 'male', 'single', 'Roman Catholic', '45 kings', 'bacag', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', NULL, '095064402786', NULL, 'daycare', NULL, 'Bactad East CDC', 'walker', 'your', 'ken', 'walker', 'one', 'luna', 'walker', 'one', 'luna', 0, NULL, NULL, NULL, NULL, NULL, 1, 0, '2025-11-10', 45.00, 78.00, 'Possible Risk of Overweight', 'Severely Stunted', 'Severely Obese', 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-11-10 06:42:58', '2025-11-10 06:42:58', NULL),
(38, 'new_applicant', '2025-11-10', 'calixtro', 'bryan', 'lomboy', NULL, '2021-11-10', 'Urdaneta City', 48, 'male', 'single', 'Roman Catholic', '55 bactad', 'bacag', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', NULL, NULL, NULL, 'daycare', NULL, 'Bactad East CDC', 'calixtro', 'tom', 'patajo', 'calixtro', 'lisa', 'alcaraz', 'calixtro', 'lisa', 'lomboy', 0, NULL, NULL, NULL, NULL, NULL, 1, 0, '2025-11-10', 77.00, 87.00, 'Possible Risk of Overweight', 'Stunted', 'Severely Obese', 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-11-10 08:36:12', '2025-11-10 08:36:12', NULL),
(39, 'new_applicant', '2025-11-10', 'west', 'jan', 'ornada', NULL, '2021-11-10', 'Urdaneta City', 48, 'male', 'single', 'Roman Catholic', '21 bilbom', 'bacag', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', NULL, NULL, NULL, 'daycare', NULL, 'Bactad East CDC', 'west', 'ben', 'tron', 'west', 'trish', 'ornada', 'west', 'trish', 'ornada', 0, NULL, NULL, NULL, NULL, NULL, 1, 0, '2025-11-10', 45.00, 77.00, 'Possible Risk of Overweight', 'Severely Stunted', 'Severely Obese', 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-11-10 08:51:40', '2025-11-10 08:51:40', NULL),
(40, 'new_applicant', '2025-11-10', 'TRY', 'TRY', 'TRY', NULL, '2025-11-10', 'Urdaneta City', 0, 'male', 'single', 'Roman Catholic', '321 TREE', 'bacag', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', NULL, '09506440263', 'bautista.noly16@gmail.com', 'daycare', NULL, 'Bactad East CDC', 'BAUTISTA', 'NOLY', NULL, 'BAUTISTA', 'NOLY', NULL, 'BAUTISTA', 'NOLY', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-11-10 09:00:43', '2025-11-10 09:00:43', NULL),
(41, 'new_applicant', '2025-11-13', 'fontanila', 'joel', 'untalan', NULL, '2023-11-13', 'Urdaneta City', 24, 'male', 'single', 'Roman Catholic', '66 santol', 'anonang', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', NULL, '09506440263', 'bauly16@gmail.com', 'daycare', NULL, 'Bactad East CDC', 'BAUTISTA', 'NOLY', NULL, 'BAUTISTA', 'NOLY', NULL, 'BAUTISTA', 'NOLY', NULL, 0, NULL, NULL, NULL, NULL, NULL, 1, 0, '2025-11-13', 45.00, 55.00, 'Possible Risk of Overweight', 'Severely Stunted', 'Severely Obese', 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-11-13 08:54:50', '2025-11-13 08:54:50', NULL),
(42, 'new_applicant', '2025-11-13', 'domingo', 'jane', 'santos', NULL, '2022-11-13', 'Urdaneta City', 36, 'female', 'single', 'Roman Catholic', '54 santos', 'anonang', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', NULL, '09506440263', 'bautisoly16@gmail.com', 'daycare', NULL, 'Bactad East CDC', 'BAUTISTA', 'NOLY', NULL, 'BAUTISTA', 'NOLY', NULL, 'BAUTISTA', 'NOLY', NULL, 0, NULL, NULL, NULL, NULL, NULL, 1, 0, '2025-11-13', 34.00, 65.00, 'Possible Risk of Overweight', 'Severely Stunted', 'Severely Obese', 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-11-13 09:12:53', '2025-11-13 09:12:53', NULL),
(43, 'new_applicant', '2025-11-18', 'cacal', 'shina', 'castro', NULL, '2009-11-18', 'Urdaneta City', 192, 'male', 'single', 'Roman Catholic', '11 capitol', 'anonang', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', NULL, '0956454564', 'castro@gmail', 'junior_high_school', NULL, NULL, 'cacal', 'nestor', 'santos', 'cacal', 'beth', 'luna', 'cacal', 'beth', 'castro', 1, NULL, NULL, '\"[\\\"Cancer(Ra11215)\\\"]\"', '\"[\\\"Injury\\\"]\"', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-11-18 10:37:19', '2025-11-18 10:37:19', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_reset_tokens`
--

INSERT INTO `password_reset_tokens` (`email`, `token`, `created_at`) VALUES
('banjobautista100802@gmail.com', 'dKR4tGVGQCE4dQYl1I6Jl7xfRaTcT4xY6ZZm26ZTguyWlOJrBQCEL5VDxmNM', '2025-10-26 15:49:40');

-- --------------------------------------------------------

--
-- Table structure for table `pending_minor_applications`
--

CREATE TABLE `pending_minor_applications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `application_type` varchar(255) NOT NULL,
  `date_applied` date NOT NULL,
  `minor_last_name` varchar(255) NOT NULL,
  `minor_first_name` varchar(255) NOT NULL,
  `minor_middle_name` varchar(255) DEFAULT NULL,
  `minor_suffix` varchar(255) DEFAULT NULL,
  `minor_date_of_birth` date NOT NULL,
  `minor_age` int(11) NOT NULL,
  `minor_sex` varchar(255) NOT NULL,
  `minor_civil_status` varchar(255) NOT NULL,
  `minor_house_no_street` varchar(255) NOT NULL,
  `minor_barangay` varchar(255) NOT NULL,
  `minor_municipality_city` varchar(255) NOT NULL,
  `minor_province` varchar(255) NOT NULL,
  `minor_region` varchar(255) NOT NULL,
  `guardian_landline_no` varchar(255) DEFAULT NULL,
  `guardian_mobile_no` varchar(255) DEFAULT NULL,
  `guardian_email_address` varchar(255) DEFAULT NULL,
  `minor_educational_attainment` varchar(255) NOT NULL,
  `minor_other_educational_attainment` varchar(255) DEFAULT NULL,
  `father_last_name` varchar(255) DEFAULT NULL,
  `father_first_name` varchar(255) DEFAULT NULL,
  `father_middle_name` varchar(255) DEFAULT NULL,
  `mother_last_name` varchar(255) DEFAULT NULL,
  `mother_first_name` varchar(255) DEFAULT NULL,
  `mother_middle_name` varchar(255) DEFAULT NULL,
  `guardian_last_name` varchar(255) DEFAULT NULL,
  `guardian_first_name` varchar(255) DEFAULT NULL,
  `guardian_middle_name` varchar(255) DEFAULT NULL,
  `is_pwd_minor` tinyint(1) NOT NULL DEFAULT 0,
  `pwd_registration_status` varchar(255) DEFAULT NULL,
  `pwd_number` varchar(255) DEFAULT NULL,
  `pwd_type_of_disability` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`pwd_type_of_disability`)),
  `pwd_cause_of_disability` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`pwd_cause_of_disability`)),
  `pwd_other_disability_cause` varchar(255) DEFAULT NULL,
  `is_daycare_student` tinyint(1) NOT NULL DEFAULT 0,
  `daycare_actual_weight_date` date DEFAULT NULL,
  `daycare_weight_kg` decimal(8,2) DEFAULT NULL,
  `daycare_height_cm` decimal(8,2) DEFAULT NULL,
  `daycare_weight_for_age` varchar(255) DEFAULT NULL,
  `daycare_height_for_age` varchar(255) DEFAULT NULL,
  `daycare_weight_for_height` varchar(255) DEFAULT NULL,
  `accomplished_by` varchar(255) NOT NULL,
  `representative_name` varchar(255) DEFAULT NULL,
  `license_no` varchar(255) DEFAULT NULL,
  `processing_officer` varchar(255) DEFAULT NULL,
  `approving_officer` varchar(255) DEFAULT NULL,
  `encoder` varchar(255) DEFAULT NULL,
  `name_of_reporting_unit` varchar(255) DEFAULT NULL,
  `control_no` varchar(255) DEFAULT NULL,
  `doctor_certified_by` varchar(255) DEFAULT NULL,
  `license_no_physician` varchar(255) DEFAULT NULL,
  `approval_status` varchar(255) NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pending_minor_applications`
--

INSERT INTO `pending_minor_applications` (`id`, `application_type`, `date_applied`, `minor_last_name`, `minor_first_name`, `minor_middle_name`, `minor_suffix`, `minor_date_of_birth`, `minor_age`, `minor_sex`, `minor_civil_status`, `minor_house_no_street`, `minor_barangay`, `minor_municipality_city`, `minor_province`, `minor_region`, `guardian_landline_no`, `guardian_mobile_no`, `guardian_email_address`, `minor_educational_attainment`, `minor_other_educational_attainment`, `father_last_name`, `father_first_name`, `father_middle_name`, `mother_last_name`, `mother_first_name`, `mother_middle_name`, `guardian_last_name`, `guardian_first_name`, `guardian_middle_name`, `is_pwd_minor`, `pwd_registration_status`, `pwd_number`, `pwd_type_of_disability`, `pwd_cause_of_disability`, `pwd_other_disability_cause`, `is_daycare_student`, `daycare_actual_weight_date`, `daycare_weight_kg`, `daycare_height_cm`, `daycare_weight_for_age`, `daycare_height_for_age`, `daycare_weight_for_height`, `accomplished_by`, `representative_name`, `license_no`, `processing_officer`, `approving_officer`, `encoder`, `name_of_reporting_unit`, `control_no`, `doctor_certified_by`, `license_no_physician`, `approval_status`, `created_at`, `updated_at`) VALUES
(2, 'new_applicant', '2025-08-11', 'test15', 'test15', 'test15', NULL, '2022-08-11', 36, 'male', 'single', '77', 'san_juan', 'Urdaneta City', 'Pangasinan', 'Ilocos Region (Region I)', NULL, '76686', '8test15@gmail.com', 'none', NULL, 'test15', 'test15', 'test15', 'test15', 'test15', 'test15', 'test15', 'test15', 'test15', 1, NULL, NULL, '[]', '[]', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 'applicant', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'pending', '2025-08-10 16:59:26', '2025-08-10 16:59:26');

-- --------------------------------------------------------

--
-- Table structure for table `pwd_minors`
--

CREATE TABLE `pwd_minors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `suffix` varchar(255) DEFAULT NULL,
  `date_of_birth` date NOT NULL,
  `age` int(11) NOT NULL,
  `sex` varchar(255) NOT NULL,
  `civil_status` varchar(255) NOT NULL,
  `pwd_registration_status` varchar(255) NOT NULL,
  `pwd_number` varchar(255) DEFAULT NULL,
  `pwd_type_of_disability` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`pwd_type_of_disability`)),
  `pwd_cause_of_disability` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`pwd_cause_of_disability`)),
  `pwd_other_disability_cause` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('M28tFMZoQWom6nOwr6PXQcCbodo57ZrnFELi3V1o', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoiM0tQZFdpWHlCaHpLZUVIUjVvYnRHejhjQ29sdEhxRGE5aWlzRG1VWSI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czo0NDoiaHR0cDovLzEyNy4wLjAuMTo4MDAwL2FkbWluL2FyY2hpdmVkLXJlY29yZHMiO31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czo0NDoiaHR0cDovLzEyNy4wLjAuMTo4MDAwL2FkbWluL2FyY2hpdmVkLXJlY29yZHMiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO30=', 1763951847),
('s0SCrDFoXm17gcUXDxAeoHt3xny6JoNXFdCkwTdh', 8, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiczF1RkZmb3l6a01zaTNheG5LSHBmOThoNjVCSjhvT2VXR2UzZHRNbSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDQ6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9hZG1pbi9jaGlsZHJlbi1yZWNvcmRzIjt9czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6ODt9', 1763873504),
('xR2rbC9G9LsLYtItePwkVXHeWjbWZZQu4pIj1cgR', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiQ1diNGV5M1V3MFJ0Umc5TWZaeWdCekdlQnVmazJiMDJudHNIc0JrTSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDA6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9hZG1pbi90YXNrcy83L2VkaXQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO30=', 1764102785);

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `task_title` varchar(255) NOT NULL,
  `task_description` text DEFAULT NULL,
  `date_created` date NOT NULL,
  `due_date` date NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `task_title`, `task_description`, `date_created`, `due_date`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Master List', 'pass it on the office', '2025-07-17', '2025-07-31', 'active', '2025-07-16 16:49:08', '2025-07-16 16:49:08'),
(2, 'Test 2', 'Test 2', '2025-08-06', '2025-08-07', 'active', '2025-08-06 07:11:31', '2025-08-06 07:11:31'),
(3, 'test 3', 'test 3', '2025-08-06', '2025-08-08', 'deleted', '2025-08-06 09:00:09', '2025-08-06 09:20:17'),
(4, 'test 4', 'test 4', '2025-08-06', '2025-08-08', 'deleted', '2025-08-06 09:20:03', '2025-08-06 09:20:09'),
(5, 'This is new', 'Testing if its work', '2025-08-15', '2025-08-20', 'active', '2025-08-15 08:00:00', '2025-08-15 08:00:00'),
(6, 'Last Master List', 'Pass as soon as possible', '2025-11-23', '2025-12-08', 'done', '2025-11-23 02:18:43', '2025-11-23 02:19:21'),
(7, 'Master List', 'Finish the master list', '2025-11-26', '2025-11-30', 'active', '2025-11-25 20:32:49', '2025-11-25 20:32:49');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'staff',
  `daycare_center` varchar(255) DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role`, `daycare_center`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Bryan Bautista', 'banjobautista100802@gmail.com', NULL, '$2y$12$CmRH/sTnCPiEHP9un3.aU.DEHxdQP18GR35kPYEbPBZEQZbLQKUIm', 'admin', NULL, NULL, '2025-10-21 16:11:08', '2025-10-21 16:11:55'),
(2, 'Banjo Bautista', 'yanyanbautista180822@gmail.com', NULL, '$2y$12$W6DI9KCHuO/u4Q2Q7rslAOS6vT./AvxS3csMRhMKLpVnGollZisBi', 'staff', NULL, NULL, '2025-07-06 11:30:40', '2025-08-31 06:17:10'),
(3, 'Bryan Bautista', 'banjobautista180822@gmail.com', NULL, '$2y$12$2Y85HOEA4FYM6bmFfhx4aOZq5u3EhtEA7ojqMlnpy5UAeFsvMGFra', 'daycare_teacher', 'Bactad East CDC', NULL, '2025-07-23 05:10:45', '2025-11-23 02:33:59'),
(4, 'Angelica Untalan', 'angelicauntalan082603@gmail.com', NULL, '$2y$12$UsOFaY3KYYvSeyPxZZ56ZObrhqHSzEKdzmFqmtiUzvX1rR2Sf9Cre', 'staff', NULL, NULL, '2025-11-24 01:30:30', '2025-11-24 01:30:30');

-- --------------------------------------------------------

--
-- Table structure for table `who_growth_data`
--

CREATE TABLE `who_growth_data` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `indicator_type` varchar(255) NOT NULL,
  `sex` enum('male','female') NOT NULL,
  `reference_value` decimal(8,3) NOT NULL,
  `l_value` decimal(8,5) NOT NULL,
  `m_value` decimal(8,5) NOT NULL,
  `s_value` decimal(8,5) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `who_growth_data`
--

INSERT INTO `who_growth_data` (`id`, `indicator_type`, `sex`, `reference_value`, `l_value`, `m_value`, `s_value`, `created_at`, `updated_at`) VALUES
(1, 'weight_for_age', 'male', 0.000, -0.35210, 3.34640, 0.14602, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(2, 'weight_for_age', 'male', 1.000, -0.35210, 4.47090, 0.13395, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(3, 'weight_for_age', 'male', 2.000, -0.35210, 5.56750, 0.12385, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(4, 'weight_for_age', 'male', 3.000, -0.35210, 6.42590, 0.11675, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(5, 'weight_for_age', 'male', 4.000, -0.35210, 7.07840, 0.11211, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(6, 'weight_for_age', 'male', 5.000, -0.35210, 7.59590, 0.10915, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(7, 'weight_for_age', 'male', 6.000, -0.35210, 8.02050, 0.10729, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(8, 'weight_for_age', 'male', 7.000, -0.25250, 8.37540, 0.10620, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(9, 'weight_for_age', 'male', 8.000, -0.15870, 8.68100, 0.10574, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(10, 'weight_for_age', 'male', 9.000, -0.07680, 8.94820, 0.10573, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(11, 'weight_for_age', 'male', 10.000, -0.00760, 9.18600, 0.10603, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(12, 'weight_for_age', 'male', 11.000, 0.04870, 9.40050, 0.10656, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(13, 'weight_for_age', 'male', 12.000, 0.09410, 9.59620, 0.10724, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(14, 'weight_for_age', 'male', 13.000, 0.13020, 9.77660, 0.10802, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(15, 'weight_for_age', 'male', 14.000, 0.15840, 9.94430, 0.10884, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(16, 'weight_for_age', 'male', 15.000, 0.18020, 10.10120, 0.10967, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(17, 'weight_for_age', 'male', 16.000, 0.19680, 10.24880, 0.11048, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(18, 'weight_for_age', 'male', 17.000, 0.20910, 10.38840, 0.11126, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(19, 'weight_for_age', 'male', 18.000, 0.21800, 10.52110, 0.11200, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(20, 'weight_for_age', 'male', 19.000, 0.22410, 10.64770, 0.11268, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(21, 'weight_for_age', 'male', 20.000, 0.22790, 10.76880, 0.11331, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(22, 'weight_for_age', 'male', 21.000, 0.22990, 10.88510, 0.11388, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(23, 'weight_for_age', 'male', 22.000, 0.23040, 10.99700, 0.11439, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(24, 'weight_for_age', 'male', 23.000, 0.22960, 11.10490, 0.11484, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(25, 'weight_for_age', 'male', 24.000, 0.22780, 11.20910, 0.11524, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(26, 'weight_for_age', 'male', 25.000, -0.19790, 12.33940, 0.11654, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(27, 'weight_for_age', 'male', 26.000, -0.20230, 12.48390, 0.11693, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(28, 'weight_for_age', 'male', 27.000, -0.20690, 12.62670, 0.11730, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(29, 'weight_for_age', 'male', 28.000, -0.21160, 12.76770, 0.11765, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(30, 'weight_for_age', 'male', 29.000, -0.21650, 12.90690, 0.11798, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(31, 'weight_for_age', 'male', 30.000, -0.22150, 13.04450, 0.11830, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(32, 'weight_for_age', 'male', 31.000, -0.22660, 13.18040, 0.11860, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(33, 'weight_for_age', 'male', 32.000, -0.23190, 13.31460, 0.11889, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(34, 'weight_for_age', 'male', 33.000, -0.23720, 13.44730, 0.11917, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(35, 'weight_for_age', 'male', 34.000, -0.24270, 13.57840, 0.11944, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(36, 'weight_for_age', 'male', 35.000, -0.24820, 13.70800, 0.11970, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(37, 'weight_for_age', 'male', 36.000, -0.25380, 13.83610, 0.11995, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(38, 'weight_for_age', 'male', 37.000, -0.25950, 13.96270, 0.12019, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(39, 'weight_for_age', 'male', 38.000, -0.26520, 14.08790, 0.12042, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(40, 'weight_for_age', 'male', 39.000, -0.27100, 14.21170, 0.12065, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(41, 'weight_for_age', 'male', 40.000, -0.27680, 14.33410, 0.12087, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(42, 'weight_for_age', 'male', 41.000, -0.28270, 14.45520, 0.12108, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(43, 'weight_for_age', 'male', 42.000, -0.28860, 14.57490, 0.12129, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(44, 'weight_for_age', 'male', 43.000, -0.29450, 14.69330, 0.12149, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(45, 'weight_for_age', 'male', 44.000, -0.30050, 14.81050, 0.12169, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(46, 'weight_for_age', 'male', 45.000, -0.30650, 14.92630, 0.12188, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(47, 'weight_for_age', 'male', 46.000, -0.31250, 15.04090, 0.12207, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(48, 'weight_for_age', 'male', 47.000, -0.31850, 15.15430, 0.12226, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(49, 'weight_for_age', 'male', 48.000, -0.32450, 15.26650, 0.12244, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(50, 'weight_for_age', 'male', 49.000, -0.33050, 15.37750, 0.12262, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(51, 'weight_for_age', 'male', 50.000, -0.33650, 15.48740, 0.12280, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(52, 'weight_for_age', 'male', 51.000, -0.34250, 15.59620, 0.12297, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(53, 'weight_for_age', 'male', 52.000, -0.34840, 15.70380, 0.12314, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(54, 'weight_for_age', 'male', 53.000, -0.35440, 15.81040, 0.12331, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(55, 'weight_for_age', 'male', 54.000, -0.36030, 15.91600, 0.12348, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(56, 'weight_for_age', 'male', 55.000, -0.36620, 16.02050, 0.12364, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(57, 'weight_for_age', 'male', 56.000, -0.37210, 16.12400, 0.12380, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(58, 'weight_for_age', 'male', 57.000, -0.37790, 16.22650, 0.12396, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(59, 'weight_for_age', 'male', 58.000, -0.38370, 16.32800, 0.12412, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(60, 'weight_for_age', 'male', 59.000, -0.38950, 16.42850, 0.12427, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(61, 'weight_for_age', 'male', 60.000, -0.39520, 16.52800, 0.12442, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(62, 'height_for_age', 'male', 0.000, 1.26700, 49.98890, 0.05311, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(63, 'height_for_age', 'male', 1.000, 0.51120, 54.72440, 0.04892, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(64, 'height_for_age', 'male', 2.000, 1.00000, 58.42300, 0.04586, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(65, 'height_for_age', 'male', 3.000, 1.00000, 61.43400, 0.04376, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(66, 'height_for_age', 'male', 4.000, 1.00000, 63.89400, 0.04221, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(67, 'height_for_age', 'male', 5.000, 1.00000, 65.93800, 0.04104, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(68, 'height_for_age', 'male', 6.000, 1.00000, 67.65800, 0.04013, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(69, 'height_for_age', 'male', 7.000, 1.00000, 69.15500, 0.03941, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(70, 'height_for_age', 'male', 8.000, 1.00000, 70.49000, 0.03884, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(71, 'height_for_age', 'male', 9.000, 1.00000, 71.70000, 0.03838, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(72, 'height_for_age', 'male', 10.000, 1.00000, 72.80800, 0.03802, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(73, 'height_for_age', 'male', 11.000, 1.00000, 73.83400, 0.03772, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(74, 'height_for_age', 'male', 12.000, 1.00000, 74.78900, 0.03748, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(75, 'height_for_age', 'male', 13.000, 1.00000, 75.68100, 0.03728, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(76, 'height_for_age', 'male', 14.000, 1.00000, 76.51800, 0.03712, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(77, 'height_for_age', 'male', 15.000, 1.00000, 77.30500, 0.03698, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(78, 'height_for_age', 'male', 16.000, 1.00000, 78.04600, 0.03688, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(79, 'height_for_age', 'male', 17.000, 1.00000, 78.74600, 0.03679, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(80, 'height_for_age', 'male', 18.000, 1.00000, 79.40800, 0.03672, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(81, 'height_for_age', 'male', 19.000, 1.00000, 80.03300, 0.03667, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(82, 'height_for_age', 'male', 20.000, 1.00000, 80.62500, 0.03664, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(83, 'height_for_age', 'male', 21.000, 1.00000, 81.18700, 0.03662, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(84, 'height_for_age', 'male', 22.000, 1.00000, 81.72000, 0.03661, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(85, 'height_for_age', 'male', 23.000, 1.00000, 82.22600, 0.03662, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(86, 'height_for_age', 'male', 24.000, 1.00000, 82.70800, 0.03663, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(87, 'height_for_age', 'male', 25.000, 1.00000, 86.81100, 0.03817, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(88, 'height_for_age', 'male', 26.000, 1.00000, 87.52000, 0.03840, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(89, 'height_for_age', 'male', 27.000, 1.00000, 88.20300, 0.03862, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(90, 'height_for_age', 'male', 28.000, 1.00000, 88.86300, 0.03884, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(91, 'height_for_age', 'male', 29.000, 1.00000, 89.50000, 0.03905, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(92, 'height_for_age', 'male', 30.000, 1.00000, 90.11600, 0.03926, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(93, 'height_for_age', 'male', 31.000, 1.00000, 90.71200, 0.03947, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(94, 'height_for_age', 'male', 32.000, 1.00000, 91.28900, 0.03968, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(95, 'height_for_age', 'male', 33.000, 1.00000, 91.84800, 0.03988, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(96, 'height_for_age', 'male', 34.000, 1.00000, 92.39000, 0.04008, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(97, 'height_for_age', 'male', 35.000, 1.00000, 92.91600, 0.04028, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(98, 'height_for_age', 'male', 36.000, 1.00000, 93.42600, 0.04048, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(99, 'height_for_age', 'male', 37.000, 1.00000, 93.92100, 0.04068, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(100, 'height_for_age', 'male', 38.000, 1.00000, 94.40200, 0.04088, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(101, 'height_for_age', 'male', 39.000, 1.00000, 94.86900, 0.04107, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(102, 'height_for_age', 'male', 40.000, 1.00000, 95.32400, 0.04126, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(103, 'height_for_age', 'male', 41.000, 1.00000, 95.76600, 0.04145, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(104, 'height_for_age', 'male', 42.000, 1.00000, 96.19700, 0.04164, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(105, 'height_for_age', 'male', 43.000, 1.00000, 96.61700, 0.04183, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(106, 'height_for_age', 'male', 44.000, 1.00000, 97.02600, 0.04201, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(107, 'height_for_age', 'male', 45.000, 1.00000, 97.42500, 0.04220, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(108, 'height_for_age', 'male', 46.000, 1.00000, 97.81500, 0.04238, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(109, 'height_for_age', 'male', 47.000, 1.00000, 98.19600, 0.04256, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(110, 'height_for_age', 'male', 48.000, 1.00000, 98.56800, 0.04274, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(111, 'height_for_age', 'male', 49.000, 1.00000, 98.93200, 0.04292, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(112, 'height_for_age', 'male', 50.000, 1.00000, 99.28900, 0.04310, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(113, 'height_for_age', 'male', 51.000, 1.00000, 99.63800, 0.04328, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(114, 'height_for_age', 'male', 52.000, 1.00000, 99.98000, 0.04345, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(115, 'height_for_age', 'male', 53.000, 1.00000, 100.31600, 0.04363, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(116, 'height_for_age', 'male', 54.000, 1.00000, 100.64500, 0.04380, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(117, 'height_for_age', 'male', 55.000, 1.00000, 100.96800, 0.04397, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(118, 'height_for_age', 'male', 56.000, 1.00000, 101.28500, 0.04414, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(119, 'height_for_age', 'male', 57.000, 1.00000, 101.59700, 0.04431, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(120, 'height_for_age', 'male', 58.000, 1.00000, 101.90200, 0.04448, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(121, 'height_for_age', 'male', 59.000, 1.00000, 102.20200, 0.04465, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(122, 'height_for_age', 'male', 60.000, 1.00000, 102.49700, 0.04481, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(123, 'weight_for_age', 'female', 0.000, -0.45780, 3.23270, 0.14477, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(124, 'weight_for_age', 'female', 1.000, -0.45780, 4.21850, 0.13374, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(125, 'weight_for_age', 'female', 2.000, -0.45780, 5.12740, 0.12328, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(126, 'weight_for_age', 'female', 3.000, -0.45780, 5.82560, 0.11545, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(127, 'weight_for_age', 'female', 4.000, -0.45780, 6.36870, 0.11003, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(128, 'weight_for_age', 'female', 5.000, -0.45780, 6.81180, 0.10641, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(129, 'weight_for_age', 'female', 6.000, -0.30150, 7.18530, 0.10404, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(130, 'weight_for_age', 'female', 7.000, -0.16910, 7.50970, 0.10255, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(131, 'weight_for_age', 'female', 8.000, -0.05920, 7.79810, 0.10168, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(132, 'weight_for_age', 'female', 9.000, 0.03210, 8.05830, 0.10123, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(133, 'weight_for_age', 'female', 10.000, 0.10780, 8.29540, 0.10106, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(134, 'weight_for_age', 'female', 11.000, 0.17060, 8.51350, 0.10110, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(135, 'weight_for_age', 'female', 12.000, 0.22270, 8.71550, 0.10127, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(136, 'weight_for_age', 'female', 13.000, 0.26570, 8.90370, 0.10155, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(137, 'weight_for_age', 'female', 14.000, 0.30140, 9.08000, 0.10189, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(138, 'weight_for_age', 'female', 15.000, 0.33090, 9.24580, 0.10228, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(139, 'weight_for_age', 'female', 16.000, 0.35510, 9.40230, 0.10269, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(140, 'weight_for_age', 'female', 17.000, 0.37490, 9.55040, 0.10311, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(141, 'weight_for_age', 'female', 18.000, 0.39100, 9.69100, 0.10352, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(142, 'weight_for_age', 'female', 19.000, 0.40390, 9.82470, 0.10392, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(143, 'weight_for_age', 'female', 20.000, 0.41400, 9.95220, 0.10430, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(144, 'weight_for_age', 'female', 21.000, 0.42180, 10.07400, 0.10466, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(145, 'weight_for_age', 'female', 22.000, 0.42750, 10.19040, 0.10500, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(146, 'weight_for_age', 'female', 23.000, 0.43150, 10.30190, 0.10531, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(147, 'weight_for_age', 'female', 24.000, 0.43400, 10.40870, 0.10560, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(148, 'weight_for_age', 'female', 25.000, -0.25260, 11.53120, 0.10821, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(149, 'weight_for_age', 'female', 26.000, -0.26060, 11.69100, 0.10884, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(150, 'weight_for_age', 'female', 27.000, -0.26870, 11.84810, 0.10945, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(151, 'weight_for_age', 'female', 28.000, -0.27680, 12.00280, 0.11005, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(152, 'weight_for_age', 'female', 29.000, -0.28490, 12.15500, 0.11062, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(153, 'weight_for_age', 'female', 30.000, -0.29300, 12.30490, 0.11118, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(154, 'weight_for_age', 'female', 31.000, -0.30100, 12.45260, 0.11172, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(155, 'weight_for_age', 'female', 32.000, -0.30910, 12.59810, 0.11224, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(156, 'weight_for_age', 'female', 33.000, -0.31700, 12.74150, 0.11274, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(157, 'weight_for_age', 'female', 34.000, -0.32490, 12.88280, 0.11323, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(158, 'weight_for_age', 'female', 35.000, -0.33280, 13.02210, 0.11370, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(159, 'weight_for_age', 'female', 36.000, -0.34050, 13.15950, 0.11416, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(160, 'weight_for_age', 'female', 37.000, -0.34820, 13.29500, 0.11460, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(161, 'weight_for_age', 'female', 38.000, -0.35580, 13.42860, 0.11503, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(162, 'weight_for_age', 'female', 39.000, -0.36330, 13.56040, 0.11545, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(163, 'weight_for_age', 'female', 40.000, -0.37080, 13.69050, 0.11586, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(164, 'weight_for_age', 'female', 41.000, -0.37810, 13.81880, 0.11626, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(165, 'weight_for_age', 'female', 42.000, -0.38540, 13.94550, 0.11664, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(166, 'weight_for_age', 'female', 43.000, -0.39260, 14.07050, 0.11702, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(167, 'weight_for_age', 'female', 44.000, -0.39980, 14.19400, 0.11739, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(168, 'weight_for_age', 'female', 45.000, -0.40680, 14.31590, 0.11775, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(169, 'weight_for_age', 'female', 46.000, -0.41380, 14.43630, 0.11810, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(170, 'weight_for_age', 'female', 47.000, -0.42080, 14.55530, 0.11845, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(171, 'weight_for_age', 'female', 48.000, -0.42760, 14.67280, 0.11878, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(172, 'weight_for_age', 'female', 49.000, -0.43440, 14.78900, 0.11911, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(173, 'weight_for_age', 'female', 50.000, -0.44110, 14.90380, 0.11944, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(174, 'weight_for_age', 'female', 51.000, -0.44780, 15.01730, 0.11976, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(175, 'weight_for_age', 'female', 52.000, -0.45430, 15.12960, 0.12007, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(176, 'weight_for_age', 'female', 53.000, -0.46080, 15.24050, 0.12038, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(177, 'weight_for_age', 'female', 54.000, -0.46720, 15.35030, 0.12068, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(178, 'weight_for_age', 'female', 55.000, -0.47350, 15.45880, 0.12098, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(179, 'weight_for_age', 'female', 56.000, -0.47980, 15.56620, 0.12127, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(180, 'weight_for_age', 'female', 57.000, -0.48590, 15.67240, 0.12156, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(181, 'weight_for_age', 'female', 58.000, -0.49200, 15.77750, 0.12184, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(182, 'weight_for_age', 'female', 59.000, -0.49800, 15.88140, 0.12212, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(183, 'weight_for_age', 'female', 60.000, -0.50390, 15.98430, 0.12240, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(184, 'height_for_age', 'female', 0.000, 1.35470, 49.25990, 0.05424, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(185, 'height_for_age', 'female', 1.000, 0.58410, 53.84200, 0.05051, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(186, 'height_for_age', 'female', 2.000, 1.00000, 57.06900, 0.04743, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(187, 'height_for_age', 'female', 3.000, 1.00000, 59.80300, 0.04510, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(188, 'height_for_age', 'female', 4.000, 1.00000, 62.08300, 0.04336, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(189, 'height_for_age', 'female', 5.000, 1.00000, 64.03200, 0.04204, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(190, 'height_for_age', 'female', 6.000, 1.00000, 65.73300, 0.04102, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(191, 'height_for_age', 'female', 7.000, 1.00000, 67.23900, 0.04021, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(192, 'height_for_age', 'female', 8.000, 1.00000, 68.59000, 0.03956, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(193, 'height_for_age', 'female', 9.000, 1.00000, 69.81500, 0.03904, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(194, 'height_for_age', 'female', 10.000, 1.00000, 70.93800, 0.03861, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(195, 'height_for_age', 'female', 11.000, 1.00000, 71.97600, 0.03825, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(196, 'height_for_age', 'female', 12.000, 1.00000, 72.94200, 0.03795, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(197, 'height_for_age', 'female', 13.000, 1.00000, 73.84400, 0.03770, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(198, 'height_for_age', 'female', 14.000, 1.00000, 74.69000, 0.03749, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(199, 'height_for_age', 'female', 15.000, 1.00000, 75.48600, 0.03731, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(200, 'height_for_age', 'female', 16.000, 1.00000, 76.23600, 0.03716, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(201, 'height_for_age', 'female', 17.000, 1.00000, 76.94500, 0.03703, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(202, 'height_for_age', 'female', 18.000, 1.00000, 77.61500, 0.03692, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(203, 'height_for_age', 'female', 19.000, 1.00000, 78.25000, 0.03683, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(204, 'height_for_age', 'female', 20.000, 1.00000, 78.85100, 0.03675, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(205, 'height_for_age', 'female', 21.000, 1.00000, 79.42100, 0.03669, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(206, 'height_for_age', 'female', 22.000, 1.00000, 79.96200, 0.03665, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(207, 'height_for_age', 'female', 23.000, 1.00000, 80.47500, 0.03661, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(208, 'height_for_age', 'female', 24.000, 1.00000, 80.96200, 0.03659, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(209, 'height_for_age', 'female', 25.000, 1.00000, 85.34300, 0.03816, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(210, 'height_for_age', 'female', 26.000, 1.00000, 86.10300, 0.03846, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(211, 'height_for_age', 'female', 27.000, 1.00000, 86.83600, 0.03875, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(212, 'height_for_age', 'female', 28.000, 1.00000, 87.54500, 0.03904, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(213, 'height_for_age', 'female', 29.000, 1.00000, 88.23100, 0.03932, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(214, 'height_for_age', 'female', 30.000, 1.00000, 88.89400, 0.03960, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(215, 'height_for_age', 'female', 31.000, 1.00000, 89.53700, 0.03988, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(216, 'height_for_age', 'female', 32.000, 1.00000, 90.15900, 0.04015, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(217, 'height_for_age', 'female', 33.000, 1.00000, 90.76300, 0.04041, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(218, 'height_for_age', 'female', 34.000, 1.00000, 91.34800, 0.04068, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(219, 'height_for_age', 'female', 35.000, 1.00000, 91.91600, 0.04094, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(220, 'height_for_age', 'female', 36.000, 1.00000, 92.46700, 0.04119, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(221, 'height_for_age', 'female', 37.000, 1.00000, 93.00200, 0.04144, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(222, 'height_for_age', 'female', 38.000, 1.00000, 93.52200, 0.04169, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(223, 'height_for_age', 'female', 39.000, 1.00000, 94.02600, 0.04193, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(224, 'height_for_age', 'female', 40.000, 1.00000, 94.51600, 0.04217, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(225, 'height_for_age', 'female', 41.000, 1.00000, 94.99200, 0.04241, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(226, 'height_for_age', 'female', 42.000, 1.00000, 95.45400, 0.04264, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(227, 'height_for_age', 'female', 43.000, 1.00000, 95.90300, 0.04287, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(228, 'height_for_age', 'female', 44.000, 1.00000, 96.34000, 0.04310, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(229, 'height_for_age', 'female', 45.000, 1.00000, 96.76400, 0.04332, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(230, 'height_for_age', 'female', 46.000, 1.00000, 97.17600, 0.04354, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(231, 'height_for_age', 'female', 47.000, 1.00000, 97.57700, 0.04376, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(232, 'height_for_age', 'female', 48.000, 1.00000, 97.96800, 0.04398, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(233, 'height_for_age', 'female', 49.000, 1.00000, 98.34700, 0.04419, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(234, 'height_for_age', 'female', 50.000, 1.00000, 98.71700, 0.04440, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(235, 'height_for_age', 'female', 51.000, 1.00000, 99.07800, 0.04461, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(236, 'height_for_age', 'female', 52.000, 1.00000, 99.42900, 0.04481, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(237, 'height_for_age', 'female', 53.000, 1.00000, 99.77100, 0.04502, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(238, 'height_for_age', 'female', 54.000, 1.00000, 100.10400, 0.04522, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(239, 'height_for_age', 'female', 55.000, 1.00000, 100.42900, 0.04541, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(240, 'height_for_age', 'female', 56.000, 1.00000, 100.74500, 0.04561, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(241, 'height_for_age', 'female', 57.000, 1.00000, 101.05300, 0.04580, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(242, 'height_for_age', 'female', 58.000, 1.00000, 101.35300, 0.04599, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(243, 'height_for_age', 'female', 59.000, 1.00000, 101.64600, 0.04618, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(244, 'height_for_age', 'female', 60.000, 1.00000, 101.93100, 0.04637, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(245, 'weight_for_height', 'male', 45.000, -0.38330, 2.44100, 0.09182, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(246, 'weight_for_height', 'male', 45.500, -0.38330, 2.50800, 0.09084, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(247, 'weight_for_height', 'male', 46.000, -0.38330, 2.57600, 0.08990, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(248, 'weight_for_height', 'male', 46.500, -0.38330, 2.64500, 0.08899, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(249, 'weight_for_height', 'male', 47.000, -0.38330, 2.71600, 0.08812, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(250, 'weight_for_height', 'male', 47.500, -0.38330, 2.78800, 0.08729, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(251, 'weight_for_height', 'male', 48.000, -0.38330, 2.86100, 0.08649, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(252, 'weight_for_height', 'male', 48.500, -0.38330, 2.93600, 0.08573, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(253, 'weight_for_height', 'male', 49.000, -0.38330, 3.01100, 0.08500, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(254, 'weight_for_height', 'male', 49.500, -0.38330, 3.08800, 0.08431, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(255, 'weight_for_height', 'male', 50.000, -0.38330, 3.16600, 0.08365, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(256, 'weight_for_height', 'male', 50.500, -0.38330, 3.24500, 0.08302, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(257, 'weight_for_height', 'male', 51.000, -0.38330, 3.32500, 0.08242, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(258, 'weight_for_height', 'male', 51.500, -0.38330, 3.40700, 0.08185, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(259, 'weight_for_height', 'male', 52.000, -0.38330, 3.48900, 0.08131, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(260, 'weight_for_height', 'male', 52.500, -0.38330, 3.57300, 0.08080, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(261, 'weight_for_height', 'male', 53.000, -0.38330, 3.65800, 0.08032, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(262, 'weight_for_height', 'male', 53.500, -0.38330, 3.74400, 0.07987, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(263, 'weight_for_height', 'male', 54.000, -0.38330, 3.83000, 0.07945, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(264, 'weight_for_height', 'male', 54.500, -0.38330, 3.91800, 0.07906, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(265, 'weight_for_height', 'male', 55.000, -0.38330, 4.00700, 0.07870, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(266, 'weight_for_height', 'male', 55.500, -0.38330, 4.09700, 0.07837, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(267, 'weight_for_height', 'male', 56.000, -0.38330, 4.18800, 0.07807, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(268, 'weight_for_height', 'male', 56.500, -0.38330, 4.28000, 0.07780, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(269, 'weight_for_height', 'male', 57.000, -0.38330, 4.37300, 0.07756, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(270, 'weight_for_height', 'male', 57.500, -0.38330, 4.46700, 0.07735, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(271, 'weight_for_height', 'male', 58.000, -0.38330, 4.56200, 0.07717, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(272, 'weight_for_height', 'male', 58.500, -0.38330, 4.65800, 0.07702, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(273, 'weight_for_height', 'male', 59.000, -0.38330, 4.75500, 0.07690, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(274, 'weight_for_height', 'male', 59.500, -0.38330, 4.85300, 0.07681, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(275, 'weight_for_height', 'male', 60.000, -0.38330, 4.95100, 0.07675, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(276, 'weight_for_height', 'male', 60.500, -0.38330, 5.05000, 0.07672, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(277, 'weight_for_height', 'male', 61.000, -0.38330, 5.15000, 0.07672, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(278, 'weight_for_height', 'male', 61.500, -0.38330, 5.25000, 0.07675, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(279, 'weight_for_height', 'male', 62.000, -0.38330, 5.35100, 0.07681, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(280, 'weight_for_height', 'male', 62.500, -0.38330, 5.45200, 0.07690, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(281, 'weight_for_height', 'male', 63.000, -0.38330, 5.55400, 0.07701, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(282, 'weight_for_height', 'male', 63.500, -0.38330, 5.65600, 0.07715, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(283, 'weight_for_height', 'male', 64.000, -0.38330, 5.75800, 0.07732, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(284, 'weight_for_height', 'male', 64.500, -0.38330, 5.86000, 0.07751, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(285, 'weight_for_height', 'male', 65.000, -0.38330, 5.96200, 0.07773, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(286, 'weight_for_height', 'male', 65.500, -0.38330, 6.06500, 0.07797, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(287, 'weight_for_height', 'male', 66.000, -0.38330, 6.16700, 0.07823, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(288, 'weight_for_height', 'male', 66.500, -0.38330, 6.27000, 0.07851, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(289, 'weight_for_height', 'male', 67.000, -0.38330, 6.37200, 0.07881, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(290, 'weight_for_height', 'male', 67.500, -0.38330, 6.47500, 0.07913, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(291, 'weight_for_height', 'male', 68.000, -0.38330, 6.57700, 0.07947, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(292, 'weight_for_height', 'male', 68.500, -0.38330, 6.68000, 0.07983, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(293, 'weight_for_height', 'male', 69.000, -0.38330, 6.78200, 0.08020, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(294, 'weight_for_height', 'male', 69.500, -0.38330, 6.88500, 0.08058, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(295, 'weight_for_height', 'male', 70.000, -0.38330, 6.98800, 0.08098, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(296, 'weight_for_height', 'male', 70.500, -0.38330, 7.09000, 0.08139, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(297, 'weight_for_height', 'male', 71.000, -0.38330, 7.19300, 0.08181, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(298, 'weight_for_height', 'male', 71.500, -0.38330, 7.29600, 0.08225, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(299, 'weight_for_height', 'male', 72.000, -0.38330, 7.39900, 0.08269, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(300, 'weight_for_height', 'male', 72.500, -0.38330, 7.50200, 0.08314, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(301, 'weight_for_height', 'male', 73.000, -0.38330, 7.60500, 0.08360, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(302, 'weight_for_height', 'male', 73.500, -0.38330, 7.70800, 0.08406, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(303, 'weight_for_height', 'male', 74.000, -0.38330, 7.81200, 0.08453, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(304, 'weight_for_height', 'male', 74.500, -0.38330, 7.91500, 0.08501, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(305, 'weight_for_height', 'male', 75.000, -0.38330, 8.01900, 0.08549, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(306, 'weight_for_height', 'male', 75.500, -0.38330, 8.12300, 0.08597, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(307, 'weight_for_height', 'male', 76.000, -0.38330, 8.22700, 0.08646, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(308, 'weight_for_height', 'male', 76.500, -0.38330, 8.33100, 0.08695, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(309, 'weight_for_height', 'male', 77.000, -0.38330, 8.43500, 0.08744, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(310, 'weight_for_height', 'male', 77.500, -0.38330, 8.54000, 0.08794, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(311, 'weight_for_height', 'male', 78.000, -0.38330, 8.64400, 0.08843, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(312, 'weight_for_height', 'male', 78.500, -0.38330, 8.74900, 0.08893, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(313, 'weight_for_height', 'male', 79.000, -0.38330, 8.85400, 0.08943, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(314, 'weight_for_height', 'male', 79.500, -0.38330, 8.95900, 0.08993, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(315, 'weight_for_height', 'male', 80.000, -0.38330, 9.06400, 0.09043, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(316, 'weight_for_height', 'male', 80.500, -0.38330, 9.17000, 0.09093, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(317, 'weight_for_height', 'male', 81.000, -0.38330, 9.27500, 0.09143, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(318, 'weight_for_height', 'male', 81.500, -0.38330, 9.38100, 0.09193, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(319, 'weight_for_height', 'male', 82.000, -0.38330, 9.48700, 0.09243, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(320, 'weight_for_height', 'male', 82.500, -0.38330, 9.59300, 0.09292, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(321, 'weight_for_height', 'male', 83.000, -0.38330, 9.69900, 0.09342, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(322, 'weight_for_height', 'male', 83.500, -0.38330, 9.80500, 0.09391, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(323, 'weight_for_height', 'male', 84.000, -0.38330, 9.91200, 0.09440, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(324, 'weight_for_height', 'male', 84.500, -0.38330, 10.01800, 0.09489, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(325, 'weight_for_height', 'male', 85.000, -0.38330, 10.12500, 0.09538, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(326, 'weight_for_height', 'male', 85.500, -0.38330, 10.23200, 0.09586, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(327, 'weight_for_height', 'male', 86.000, -0.38330, 10.33900, 0.09634, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(328, 'weight_for_height', 'male', 86.500, -0.38330, 10.44600, 0.09681, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(329, 'weight_for_height', 'male', 87.000, -0.38330, 10.55400, 0.09729, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(330, 'weight_for_height', 'male', 87.500, -0.38330, 10.66100, 0.09776, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(331, 'weight_for_height', 'male', 88.000, -0.38330, 10.76900, 0.09823, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(332, 'weight_for_height', 'male', 88.500, -0.38330, 10.87700, 0.09869, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(333, 'weight_for_height', 'male', 89.000, -0.38330, 10.98500, 0.09915, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(334, 'weight_for_height', 'male', 89.500, -0.38330, 11.09300, 0.09961, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(335, 'weight_for_height', 'male', 90.000, -0.38330, 11.20100, 0.10006, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(336, 'weight_for_height', 'male', 90.500, -0.38330, 11.30900, 0.10051, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(337, 'weight_for_height', 'male', 91.000, -0.38330, 11.41800, 0.10096, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(338, 'weight_for_height', 'male', 91.500, -0.38330, 11.52600, 0.10140, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(339, 'weight_for_height', 'male', 92.000, -0.38330, 11.63500, 0.10184, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(340, 'weight_for_height', 'male', 92.500, -0.38330, 11.74400, 0.10228, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(341, 'weight_for_height', 'male', 93.000, -0.38330, 11.85300, 0.10271, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(342, 'weight_for_height', 'male', 93.500, -0.38330, 11.96200, 0.10314, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(343, 'weight_for_height', 'male', 94.000, -0.38330, 12.07100, 0.10357, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(344, 'weight_for_height', 'male', 94.500, -0.38330, 12.18000, 0.10399, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(345, 'weight_for_height', 'male', 95.000, -0.38330, 12.29000, 0.10441, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(346, 'weight_for_height', 'male', 95.500, -0.38330, 12.39900, 0.10483, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(347, 'weight_for_height', 'male', 96.000, -0.38330, 12.50900, 0.10524, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(348, 'weight_for_height', 'male', 96.500, -0.38330, 12.61900, 0.10565, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(349, 'weight_for_height', 'male', 97.000, -0.38330, 12.72800, 0.10606, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(350, 'weight_for_height', 'male', 97.500, -0.38330, 12.83800, 0.10646, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(351, 'weight_for_height', 'male', 98.000, -0.38330, 12.94800, 0.10686, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(352, 'weight_for_height', 'male', 98.500, -0.38330, 13.05800, 0.10726, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(353, 'weight_for_height', 'male', 99.000, -0.38330, 13.16900, 0.10766, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(354, 'weight_for_height', 'male', 99.500, -0.38330, 13.27900, 0.10805, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(355, 'weight_for_height', 'male', 100.000, -0.38330, 13.39000, 0.10844, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(356, 'weight_for_height', 'male', 100.500, -0.38330, 13.50000, 0.10883, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(357, 'weight_for_height', 'male', 101.000, -0.38330, 13.61200, 0.10922, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(358, 'weight_for_height', 'male', 101.500, -0.38330, 13.72300, 0.10960, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(359, 'weight_for_height', 'male', 102.000, -0.38330, 13.83500, 0.10999, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(360, 'weight_for_height', 'male', 102.500, -0.38330, 13.94700, 0.11037, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(361, 'weight_for_height', 'male', 103.000, -0.38330, 14.05900, 0.11075, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(362, 'weight_for_height', 'male', 103.500, -0.38330, 14.17200, 0.11113, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(363, 'weight_for_height', 'male', 104.000, -0.38330, 14.28500, 0.11150, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(364, 'weight_for_height', 'male', 104.500, -0.38330, 14.39800, 0.11188, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(365, 'weight_for_height', 'male', 105.000, -0.38330, 14.51200, 0.11225, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(366, 'weight_for_height', 'male', 105.500, -0.38330, 14.62600, 0.11262, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(367, 'weight_for_height', 'male', 106.000, -0.38330, 14.74100, 0.11299, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(368, 'weight_for_height', 'male', 106.500, -0.38330, 14.85600, 0.11336, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(369, 'weight_for_height', 'male', 107.000, -0.38330, 14.97200, 0.11373, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(370, 'weight_for_height', 'male', 107.500, -0.38330, 15.08800, 0.11409, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(371, 'weight_for_height', 'male', 108.000, -0.38330, 15.20400, 0.11446, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(372, 'weight_for_height', 'male', 108.500, -0.38330, 15.32100, 0.11482, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(373, 'weight_for_height', 'male', 109.000, -0.38330, 15.43800, 0.11518, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(374, 'weight_for_height', 'male', 109.500, -0.38330, 18.50200, 0.12520, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(375, 'weight_for_height', 'male', 110.000, -0.38330, 18.68300, 0.12590, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(376, 'weight_for_height', 'female', 45.000, -0.49470, 2.36800, 0.09452, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(377, 'weight_for_height', 'female', 45.500, -0.49470, 2.43800, 0.09341, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(378, 'weight_for_height', 'female', 46.000, -0.49470, 2.51000, 0.09234, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(379, 'weight_for_height', 'female', 46.500, -0.49470, 2.58300, 0.09130, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(380, 'weight_for_height', 'female', 47.000, -0.49470, 2.65700, 0.09030, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(381, 'weight_for_height', 'female', 47.500, -0.49470, 2.73200, 0.08934, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(382, 'weight_for_height', 'female', 48.000, -0.49470, 2.80800, 0.08842, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(383, 'weight_for_height', 'female', 48.500, -0.49470, 2.88600, 0.08753, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(384, 'weight_for_height', 'female', 49.000, -0.49470, 2.96400, 0.08668, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(385, 'weight_for_height', 'female', 49.500, -0.49470, 3.04400, 0.08587, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(386, 'weight_for_height', 'female', 50.000, -0.49470, 3.12500, 0.08510, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(387, 'weight_for_height', 'female', 50.500, -0.49470, 3.20800, 0.08437, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(388, 'weight_for_height', 'female', 51.000, -0.49470, 3.29200, 0.08367, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(389, 'weight_for_height', 'female', 51.500, -0.49470, 3.37800, 0.08301, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(390, 'weight_for_height', 'female', 52.000, -0.49470, 3.46500, 0.08239, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(391, 'weight_for_height', 'female', 52.500, -0.49470, 3.55400, 0.08181, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(392, 'weight_for_height', 'female', 53.000, -0.49470, 3.64400, 0.08126, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(393, 'weight_for_height', 'female', 53.500, -0.49470, 3.73600, 0.08076, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(394, 'weight_for_height', 'female', 54.000, -0.49470, 3.82900, 0.08030, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(395, 'weight_for_height', 'female', 54.500, -0.49470, 3.92400, 0.07988, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(396, 'weight_for_height', 'female', 55.000, -0.49470, 4.02000, 0.07951, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(397, 'weight_for_height', 'female', 55.500, -0.49470, 4.11800, 0.07919, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(398, 'weight_for_height', 'female', 56.000, -0.49470, 4.21800, 0.07891, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(399, 'weight_for_height', 'female', 56.500, -0.49470, 4.31900, 0.07869, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(400, 'weight_for_height', 'female', 57.000, -0.49470, 4.42200, 0.07852, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(401, 'weight_for_height', 'female', 57.500, -0.49470, 4.52600, 0.07840, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(402, 'weight_for_height', 'female', 58.000, -0.49470, 4.63200, 0.07834, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(403, 'weight_for_height', 'female', 58.500, -0.49470, 4.73900, 0.07834, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(404, 'weight_for_height', 'female', 59.000, -0.49470, 4.84800, 0.07840, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(405, 'weight_for_height', 'female', 59.500, -0.49470, 4.95800, 0.07851, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(406, 'weight_for_height', 'female', 60.000, -0.49470, 5.07000, 0.07868, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(407, 'weight_for_height', 'female', 60.500, -0.49470, 5.18300, 0.07892, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(408, 'weight_for_height', 'female', 61.000, -0.49470, 5.29800, 0.07921, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(409, 'weight_for_height', 'female', 61.500, -0.49470, 5.41400, 0.07955, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(410, 'weight_for_height', 'female', 62.000, -0.49470, 5.53100, 0.07994, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(411, 'weight_for_height', 'female', 62.500, -0.49470, 5.65000, 0.08038, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(412, 'weight_for_height', 'female', 63.000, -0.49470, 5.76900, 0.08086, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(413, 'weight_for_height', 'female', 63.500, -0.49470, 5.89000, 0.08138, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(414, 'weight_for_height', 'female', 64.000, -0.49470, 6.01200, 0.08194, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(415, 'weight_for_height', 'female', 64.500, -0.49470, 6.13500, 0.08254, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(416, 'weight_for_height', 'female', 65.000, -0.49470, 6.25900, 0.08316, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(417, 'weight_for_height', 'female', 65.500, -0.49470, 6.38300, 0.08382, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(418, 'weight_for_height', 'female', 66.000, -0.49470, 6.50900, 0.08450, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(419, 'weight_for_height', 'female', 66.500, -0.49470, 6.63500, 0.08520, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(420, 'weight_for_height', 'female', 67.000, -0.49470, 6.76200, 0.08591, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(421, 'weight_for_height', 'female', 67.500, -0.49470, 6.89000, 0.08664, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(422, 'weight_for_height', 'female', 68.000, -0.49470, 7.01800, 0.08738, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(423, 'weight_for_height', 'female', 68.500, -0.49470, 7.14700, 0.08812, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(424, 'weight_for_height', 'female', 69.000, -0.49470, 7.27700, 0.08887, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(425, 'weight_for_height', 'female', 69.500, -0.49470, 7.40700, 0.08962, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(426, 'weight_for_height', 'female', 70.000, -0.49470, 7.53800, 0.09038, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(427, 'weight_for_height', 'female', 70.500, -0.49470, 7.66900, 0.09113, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(428, 'weight_for_height', 'female', 71.000, -0.49470, 7.80000, 0.09188, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(429, 'weight_for_height', 'female', 71.500, -0.49470, 7.93100, 0.09262, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(430, 'weight_for_height', 'female', 72.000, -0.49470, 8.06200, 0.09335, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(431, 'weight_for_height', 'female', 72.500, -0.49470, 8.19300, 0.09407, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(432, 'weight_for_height', 'female', 73.000, -0.49470, 8.32400, 0.09478, '2025-07-09 12:36:07', '2025-07-09 12:36:07');
INSERT INTO `who_growth_data` (`id`, `indicator_type`, `sex`, `reference_value`, `l_value`, `m_value`, `s_value`, `created_at`, `updated_at`) VALUES
(433, 'weight_for_height', 'female', 73.500, -0.49470, 8.45500, 0.09548, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(434, 'weight_for_height', 'female', 74.000, -0.49470, 8.58600, 0.09617, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(435, 'weight_for_height', 'female', 74.500, -0.49470, 8.71600, 0.09685, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(436, 'weight_for_height', 'female', 75.000, -0.49470, 8.84700, 0.09752, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(437, 'weight_for_height', 'female', 75.500, -0.49470, 8.97700, 0.09817, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(438, 'weight_for_height', 'female', 76.000, -0.49470, 9.10600, 0.09881, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(439, 'weight_for_height', 'female', 76.500, -0.49470, 9.23500, 0.09944, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(440, 'weight_for_height', 'female', 77.000, -0.49470, 9.36400, 0.10006, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(441, 'weight_for_height', 'female', 77.500, -0.49470, 9.49200, 0.10066, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(442, 'weight_for_height', 'female', 78.000, -0.49470, 9.62000, 0.10125, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(443, 'weight_for_height', 'female', 78.500, -0.49470, 9.74700, 0.10183, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(444, 'weight_for_height', 'female', 79.000, -0.49470, 9.87400, 0.10239, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(445, 'weight_for_height', 'female', 79.500, -0.49470, 10.00000, 0.10294, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(446, 'weight_for_height', 'female', 80.000, -0.49470, 10.12600, 0.10348, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(447, 'weight_for_height', 'female', 80.500, -0.49470, 10.25200, 0.10401, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(448, 'weight_for_height', 'female', 81.000, -0.49470, 10.37700, 0.10453, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(449, 'weight_for_height', 'female', 81.500, -0.49470, 10.50200, 0.10503, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(450, 'weight_for_height', 'female', 82.000, -0.49470, 10.62600, 0.10552, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(451, 'weight_for_height', 'female', 82.500, -0.49470, 10.75000, 0.10600, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(452, 'weight_for_height', 'female', 83.000, -0.49470, 10.87300, 0.10647, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(453, 'weight_for_height', 'female', 83.500, -0.49470, 10.99600, 0.10693, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(454, 'weight_for_height', 'female', 84.000, -0.49470, 11.11900, 0.10737, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(455, 'weight_for_height', 'female', 84.500, -0.49470, 11.24100, 0.10781, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(456, 'weight_for_height', 'female', 85.000, -0.49470, 11.36300, 0.10824, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(457, 'weight_for_height', 'female', 85.500, -0.49470, 11.48500, 0.10866, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(458, 'weight_for_height', 'female', 86.000, -0.49470, 11.60600, 0.10907, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(459, 'weight_for_height', 'female', 86.500, -0.49470, 11.72700, 0.10948, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(460, 'weight_for_height', 'female', 87.000, -0.49470, 11.84700, 0.10988, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(461, 'weight_for_height', 'female', 87.500, -0.49470, 11.96700, 0.11027, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(462, 'weight_for_height', 'female', 88.000, -0.49470, 12.08700, 0.11065, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(463, 'weight_for_height', 'female', 88.500, -0.49470, 12.20600, 0.11103, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(464, 'weight_for_height', 'female', 89.000, -0.49470, 12.32500, 0.11140, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(465, 'weight_for_height', 'female', 89.500, -0.49470, 12.44400, 0.11177, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(466, 'weight_for_height', 'female', 90.000, -0.49470, 12.56200, 0.11213, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(467, 'weight_for_height', 'female', 90.500, -0.49470, 12.68000, 0.11249, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(468, 'weight_for_height', 'female', 91.000, -0.49470, 12.79800, 0.11285, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(469, 'weight_for_height', 'female', 91.500, -0.49470, 12.91500, 0.11320, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(470, 'weight_for_height', 'female', 92.000, -0.49470, 13.03200, 0.11355, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(471, 'weight_for_height', 'female', 92.500, -0.49470, 13.14900, 0.11390, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(472, 'weight_for_height', 'female', 93.000, -0.49470, 13.26600, 0.11425, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(473, 'weight_for_height', 'female', 93.500, -0.49470, 13.38300, 0.11460, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(474, 'weight_for_height', 'female', 94.000, -0.49470, 13.50000, 0.11495, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(475, 'weight_for_height', 'female', 94.500, -0.49470, 13.61600, 0.11529, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(476, 'weight_for_height', 'female', 95.000, -0.49470, 13.73300, 0.11564, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(477, 'weight_for_height', 'female', 95.500, -0.49470, 13.84900, 0.11599, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(478, 'weight_for_height', 'female', 96.000, -0.49470, 13.96500, 0.11634, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(479, 'weight_for_height', 'female', 96.500, -0.49470, 14.08100, 0.11669, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(480, 'weight_for_height', 'female', 97.000, -0.49470, 14.19700, 0.11704, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(481, 'weight_for_height', 'female', 97.500, -0.49470, 14.31300, 0.11739, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(482, 'weight_for_height', 'female', 98.000, -0.49470, 14.42900, 0.11775, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(483, 'weight_for_height', 'female', 98.500, -0.49470, 14.54500, 0.11811, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(484, 'weight_for_height', 'female', 99.000, -0.49470, 14.66100, 0.11847, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(485, 'weight_for_height', 'female', 99.500, -0.49470, 14.77700, 0.11883, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(486, 'weight_for_height', 'female', 100.000, -0.49470, 14.89300, 0.11920, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(487, 'weight_for_height', 'female', 100.500, -0.49470, 15.00900, 0.11957, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(488, 'weight_for_height', 'female', 101.000, -0.49470, 15.12600, 0.11994, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(489, 'weight_for_height', 'female', 101.500, -0.49470, 15.24300, 0.12032, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(490, 'weight_for_height', 'female', 102.000, -0.49470, 15.36000, 0.12070, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(491, 'weight_for_height', 'female', 102.500, -0.49470, 15.47700, 0.12108, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(492, 'weight_for_height', 'female', 103.000, -0.49470, 15.59500, 0.12147, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(493, 'weight_for_height', 'female', 103.500, -0.49470, 15.71300, 0.12186, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(494, 'weight_for_height', 'female', 104.000, -0.49470, 15.83200, 0.12226, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(495, 'weight_for_height', 'female', 104.500, -0.49470, 15.95100, 0.12266, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(496, 'weight_for_height', 'female', 105.000, -0.49470, 16.07000, 0.12306, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(497, 'weight_for_height', 'female', 105.500, -0.49470, 16.19000, 0.12347, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(498, 'weight_for_height', 'female', 106.000, -0.49470, 16.31000, 0.12388, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(499, 'weight_for_height', 'female', 106.500, -0.49470, 16.43100, 0.12430, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(500, 'weight_for_height', 'female', 107.000, -0.49470, 16.55200, 0.12472, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(501, 'weight_for_height', 'female', 107.500, -0.49470, 16.67400, 0.12514, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(502, 'weight_for_height', 'female', 108.000, -0.49470, 16.79600, 0.12557, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(503, 'weight_for_height', 'female', 108.500, -0.49470, 16.91900, 0.12600, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(504, 'weight_for_height', 'female', 109.000, -0.49470, 17.04200, 0.12644, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(505, 'weight_for_height', 'female', 109.500, -0.49470, 17.16600, 0.12688, '2025-07-09 12:36:07', '2025-07-09 12:36:07'),
(506, 'weight_for_height', 'female', 110.000, -0.49470, 17.29100, 0.12732, '2025-07-09 12:36:07', '2025-07-09 12:36:07');

-- --------------------------------------------------------

--
-- Structure for view `archived_with_minors`
--
DROP TABLE IF EXISTS `archived_with_minors`;

CREATE ALGORITHM=UNDEFINED DEFINER=`` SQL SECURITY DEFINER VIEW `archived_with_minors`  AS SELECT `a`.`id` AS `id`, `a`.`name` AS `name`, `a`.`brgy` AS `brgy`, `a`.`age` AS `age`, `a`.`sex` AS `sex`, `a`.`daycare_center` AS `daycare_center`, `a`.`original_section` AS `original_section`, `a`.`original_id` AS `original_id`, `a`.`minor_id` AS `minor_id`, `a`.`record_type` AS `record_type`, `a`.`created_at` AS `created_at`, `a`.`updated_at` AS `updated_at`, `m`.`minor_last_name` AS `minor_last_name`, `m`.`minor_first_name` AS `minor_first_name`, `m`.`minor_middle_name` AS `minor_middle_name`, `m`.`minor_barangay` AS `minor_barangay` FROM (`archived_records` `a` left join `minors` `m` on(`a`.`minor_id` = `m`.`id`)) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aids`
--
ALTER TABLE `aids`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `full_name` (`full_name`);

--
-- Indexes for table `aid_assistances`
--
ALTER TABLE `aid_assistances`
  ADD PRIMARY KEY (`id`),
  ADD KEY `aid_assistances_minor_id_foreign` (`minor_id`);

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `archived_records`
--
ALTER TABLE `archived_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_archived_records_minors` (`minor_id`);

--
-- Indexes for table `audits`
--
ALTER TABLE `audits`
  ADD PRIMARY KEY (`id`),
  ADD KEY `audits_auditable_type_auditable_id_index` (`auditable_type`,`auditable_id`),
  ADD KEY `audits_user_id_user_type_index` (`user_id`,`user_type`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `minors`
--
ALTER TABLE `minors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`),
  ADD KEY `password_reset_tokens_email_index` (`email`);

--
-- Indexes for table `pending_minor_applications`
--
ALTER TABLE `pending_minor_applications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pwd_minors`
--
ALTER TABLE `pwd_minors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `who_growth_data`
--
ALTER TABLE `who_growth_data`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `who_data_unique` (`indicator_type`,`sex`,`reference_value`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aids`
--
ALTER TABLE `aids`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `aid_assistances`
--
ALTER TABLE `aid_assistances`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `archived_records`
--
ALTER TABLE `archived_records`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `audits`
--
ALTER TABLE `audits`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `minors`
--
ALTER TABLE `minors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `pending_minor_applications`
--
ALTER TABLE `pending_minor_applications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pwd_minors`
--
ALTER TABLE `pwd_minors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `who_growth_data`
--
ALTER TABLE `who_growth_data`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=507;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `aid_assistances`
--
ALTER TABLE `aid_assistances`
  ADD CONSTRAINT `aid_assistances_minor_id_foreign` FOREIGN KEY (`minor_id`) REFERENCES `minors` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `archived_records`
--
ALTER TABLE `archived_records`
  ADD CONSTRAINT `fk_archived_records_minors` FOREIGN KEY (`minor_id`) REFERENCES `minors` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
